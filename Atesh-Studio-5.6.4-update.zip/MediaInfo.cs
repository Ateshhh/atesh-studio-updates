using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Interop;

public static class DostCover {
    public static System.Collections.Generic.Dictionary<string,string> ReadWaveTags(string path) {
        var tags=new System.Collections.Generic.Dictionary<string,string>();
        try {
            using(var reader=new System.IO.BinaryReader(System.IO.File.OpenRead(path))) {
                if(System.Text.Encoding.ASCII.GetString(reader.ReadBytes(4))!="RIFF") return tags;
                reader.ReadUInt32();
                if(System.Text.Encoding.ASCII.GetString(reader.ReadBytes(4))!="WAVE") return tags;
                while(reader.BaseStream.Position+8<=reader.BaseStream.Length) {
                    string id=System.Text.Encoding.ASCII.GetString(reader.ReadBytes(4));
                    uint size=reader.ReadUInt32();long end=reader.BaseStream.Position+size;
                    if(end>reader.BaseStream.Length) break;
                    if(id=="LIST" && size>=4 && System.Text.Encoding.ASCII.GetString(reader.ReadBytes(4))=="INFO") {
                        while(reader.BaseStream.Position+8<=end) {
                            string key=System.Text.Encoding.ASCII.GetString(reader.ReadBytes(4));uint length=reader.ReadUInt32();
                            long next=reader.BaseStream.Position+length;
                            if(next>end) break;
                            if(length<=65536 && (key=="INAM" || key=="IART" || key=="IPRD"))
                                tags[key]=System.Text.Encoding.Default.GetString(reader.ReadBytes((int)length)).TrimEnd('\0');
                            reader.BaseStream.Position=next+(length%2);
                        }
                    }
                    reader.BaseStream.Position=end+(size%2);
                }
            }
        } catch { }
        return tags;
    }
    [StructLayout(LayoutKind.Sequential)] struct Size { public int Width; public int Height; }
    [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface ImageFactory { [PreserveSig] int GetImage(Size size, int flags, out IntPtr bitmap); }
    [DllImport("shell32.dll", CharSet=CharSet.Unicode, PreserveSig=true)]
    static extern int SHCreateItemFromParsingName(string path, IntPtr context, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out ImageFactory factory);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr handle);
    public static BitmapSource Read(string path) {
        ImageFactory factory=null; IntPtr handle=IntPtr.Zero;
        try {
            Guid iid=new Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b");
            if(SHCreateItemFromParsingName(path,IntPtr.Zero,ref iid,out factory)!=0) return null;
            // THUMBNAILONLY avoids substituting a generic file icon for album art.
            if(factory.GetImage(new Size{Width=256,Height=256},8,out handle)!=0 || handle==IntPtr.Zero) return null;
            BitmapSource image=Imaging.CreateBitmapSourceFromHBitmap(handle,IntPtr.Zero,Int32Rect.Empty,BitmapSizeOptions.FromEmptyOptions());
            image.Freeze(); return image;
        } catch { return null; }
        finally { if(handle!=IntPtr.Zero) DeleteObject(handle); if(factory!=null) Marshal.ReleaseComObject(factory); }
    }
}
