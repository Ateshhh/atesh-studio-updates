﻿$script:collectionMeta=@{}
$script:coverAssetDir=Join-Path $script:dataDir 'kapaklar'
$script:draftCover=''
$script:assetCache=@{}
function Read-CoverAsset([string]$relative) {
 if(-not $relative -or $relative -notmatch '^kapaklar/[a-f0-9]{32}\.png$'){return $null}
 $file=Join-Path $script:dataDir $relative
 if($script:assetCache.ContainsKey($file)){return $script:assetCache[$file]}
 if(-not (Test-Path -LiteralPath $file)){return $null}
 try{
  $bitmap=[Windows.Media.Imaging.BitmapImage]::new();$bitmap.BeginInit();$bitmap.CacheOption='OnLoad';$bitmap.DecodePixelWidth=512;$bitmap.UriSource=[Uri]::new($file);$bitmap.EndInit();$bitmap.Freeze();$script:assetCache[$file]=$bitmap;return $bitmap
 }catch{return $null}
}
function Import-CoverAsset([string]$file) {
 # Decode before saving; the original image is never changed or locked.
 $bitmap=[Windows.Media.Imaging.BitmapImage]::new();$bitmap.BeginInit();$bitmap.CacheOption='OnLoad';$bitmap.DecodePixelWidth=800;$bitmap.UriSource=[Uri]::new($file);$bitmap.EndInit();$bitmap.Freeze()
 [void][IO.Directory]::CreateDirectory($script:coverAssetDir)
 $name=[Guid]::NewGuid().ToString('N')+'.png';$target=Join-Path $script:coverAssetDir $name
 $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new();$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap));$stream=[IO.File]::Create($target)
 try{$encoder.Save($stream)}finally{$stream.Dispose()}
 return 'kapaklar/'+$name
}
function Choose-CoverAsset {
 $dialog=[Microsoft.Win32.OpenFileDialog]::new();$dialog.Title='Kapak resmi seç';$dialog.Filter='Resimler|*.jpg;*.jpeg;*.png;*.bmp';if($dialog.ShowDialog($window)){return Import-CoverAsset $dialog.FileName};return $null
}
function Refresh-CollectionVisual {
 $meta=$script:collectionMeta[$script:view]
 $cover=if($meta){Read-CoverAsset $meta.Cover}else{$null}
 $ui.CollectionHeaderCover.Source=$cover
 $ui.CollectionHeaderCover.Visibility=if($cover){'Visible'}else{'Collapsed'}
 if($cover){$script:scene.SetCover($cover)}elseif($script:current){$script:scene.SetCover((Get-Cover $script:current.Path))}else{$script:scene.SetCover($null)}
}
function Move-EditorTracks([int]$direction) {
 $rows=@($ui.CollectionTracks.ItemsSource);$selected=@($ui.CollectionTracks.SelectedItems | ForEach-Object {$_.Id})
 if($rows.Count -lt 2 -or $selected.Count -eq 0){return}
 if($direction -lt 0){for($i=1;$i -lt $rows.Count;$i++){if($selected -contains $rows[$i].Id -and $selected -notcontains $rows[$i-1].Id){$temp=$rows[$i-1];$rows[$i-1]=$rows[$i];$rows[$i]=$temp}}}
 else{for($i=$rows.Count-2;$i -ge 0;$i--){if($selected -contains $rows[$i].Id -and $selected -notcontains $rows[$i+1].Id){$temp=$rows[$i+1];$rows[$i+1]=$rows[$i];$rows[$i]=$temp}}}
 $ui.CollectionTracks.ItemsSource=$rows
 foreach($track in $rows){if($selected -contains $track.Id){[void]$ui.CollectionTracks.SelectedItems.Add($track)}}
}
function Move-EditorTrack([string]$id,[int]$direction) {
 $rows=@($ui.CollectionTracks.ItemsSource);$ids=@($rows | ForEach-Object {$_.Id});$i=[Array]::IndexOf($ids,$id);$j=$i+$direction
 if($i -lt 0 -or $j -lt 0 -or $j -ge $rows.Count){return}
 $selected=@($ui.CollectionTracks.SelectedItems | ForEach-Object {$_.Id})
 $temp=$rows[$i];$rows[$i]=$rows[$j];$rows[$j]=$temp;$ui.CollectionTracks.ItemsSource=$rows
 foreach($track in $rows){if($selected -contains $track.Id){[void]$ui.CollectionTracks.SelectedItems.Add($track)}}
 $ui.CollectionTracks.ScrollIntoView($rows[$j])
}
function Remove-Collection([string]$name) {
 if(-not $lists.Contains($name)){return}
 $oldNames=@($lists.ToArray());$oldMeta=$script:collectionMeta[$name];$oldMembership=@{}
 foreach($track in $library){$oldMembership[$track.Id]=@($track.Lists);$track.Lists=@($track.Lists | Where-Object {$_ -ine $name})}
 $lists.Remove($name);$script:collectionMeta.Remove($name);Save-Library
 if(-not $script:lastSaveSucceeded){$lists.Clear();foreach($n in $oldNames){[void]$lists.Add($n)};if($oldMeta){$script:collectionMeta[$name]=$oldMeta};foreach($track in $library){$track.Lists=$oldMembership[$track.Id]};$ui.CollectionError.Text='Liste silinemedi. Kayıt klasörünü kontrol et.';return}
 $ui.CollectionOverlay.Visibility='Collapsed';$ui.Lists.ItemsSource=$lists.ToArray();$ui.Lists.SelectedIndex=-1;$script:view='all';$ui.Heading.Text='Tüm şarkılar';Refresh-Tracks
 $ui.Status.Text='Liste silindi: '+$name+'. Müzik dosyaların kütüphanede duruyor.'
}
function Duplicate-Collection {
 $original=$script:editingCollection
 if(-not $original){return}
 $baseName=$original;if($baseName.Length -gt 65){$baseName=$baseName.Substring(0,65)}
 $copyName=$baseName+' (kopya)';$n=2
 while($lists -contains $copyName){$copyName=$baseName+" (kopya $n)";$n++}
 $script:editingCollection=$null;$ui.CollectionName.Text=$copyName;$ui.CollectionTitle.Text='Listeyi çoğalt';$ui.CollectionSave.Content='Kopyayı oluştur'
 $ui.DeleteCollection.Visibility='Collapsed';$ui.DuplicateCollection.Visibility='Collapsed'
 $ui.CollectionError.Text='Adı, kapağı ve şarkıları düzenleyip kopyayı oluşturabilirsin.'
}
function Set-TrackCover($track,[string]$asset) {
 if(-not $track){return}
 $old=$track.Cover
 if(-not $track.PSObject.Properties['Cover']){$track | Add-Member NoteProperty Cover ''}
 $track.Cover=$asset;Save-Library
 if(-not $script:lastSaveSucceeded){$track.Cover=$old;return}
 $script:coverCache.Remove($track.Path);Refresh-Tracks
 if($script:current -and $script:current.Id -eq $track.Id){$ui.NowCover.Source=Get-Cover $track.Path;$script:scene.SetCover($ui.NowCover.Source);Sync-Mini}
 $ui.Status.Text='Şarkı kapağı güncellendi.'
}
function Initialize-CollectionExtras {
 $ui.CollectionTracks.AddHandler([Windows.Controls.Button]::ClickEvent,[Windows.RoutedEventHandler]{param($sender,$e) if($e.Source -is [Windows.Controls.Button] -and $e.Source.Tag){Move-EditorTrack ([string]$e.Source.Tag) ([int]$e.Source.CommandParameter);$e.Handled=$true}})
 $ui.ChooseCollectionCover.Add_Click({try{$asset=Choose-CoverAsset;if($asset){$script:draftCover=$asset;$ui.CollectionCoverPreview.Source=Read-CoverAsset $asset;$ui.CollectionError.Text=''}}catch{$ui.CollectionError.Text='Resim açılamadı. Geçerli bir JPG veya PNG seç.'}})
 $ui.ClearCollectionCover.Add_Click({$script:draftCover='';$ui.CollectionCoverPreview.Source=$null})
 $ui.EditorUp.Add_Click({Move-EditorTracks -1});$ui.EditorDown.Add_Click({Move-EditorTracks 1})
 $ui.DuplicateCollection.Add_Click({Duplicate-Collection})
 $ui.DeleteCollection.Add_Click({
  if(-not $script:editingCollection){return}
  $answer=[Windows.MessageBox]::Show($window,"'$script:editingCollection' listesi silinsin mi?`nMüzik dosyaların silinmez.",'Listeyi sil',[Windows.MessageBoxButton]::YesNo,[Windows.MessageBoxImage]::Question,[Windows.MessageBoxResult]::No)
  if($answer -eq [Windows.MessageBoxResult]::Yes){Remove-Collection $script:editingCollection}
 })
 $ui.TrackCover.Add_Click({
  $track=Get-SelectedTrack;if(-not $track){return}
  $menu=[Windows.Controls.ContextMenu]::new()
  $choose=[Windows.Controls.MenuItem]::new();$choose.Header='Kapak resmi seç…';$choose.Tag=$track
  $choose.Add_Click({param($sender,$e) try{$asset=Choose-CoverAsset;if($asset){Set-TrackCover $sender.Tag $asset}}catch{$ui.Status.Text='Resim açılamadı. Geçerli bir JPG veya PNG seç.'}})
  $clear=[Windows.Controls.MenuItem]::new();$clear.Header='Özel kapağı kaldır';$clear.Tag=$track;$clear.IsEnabled=[bool]$track.Cover
  $clear.Add_Click({param($sender,$e) Set-TrackCover $sender.Tag ''})
  [void]$menu.Items.Add($choose);[void]$menu.Items.Add($clear);$menu.PlacementTarget=$ui.TrackCover;$menu.IsOpen=$true
 })
}
