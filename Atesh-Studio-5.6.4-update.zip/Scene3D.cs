﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Media3D;

public class DostScene {
    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
    public static void DarkTitle(IntPtr hwnd) {
        try { int enabled=1; DwmSetWindowAttribute(hwnd,20,ref enabled,4); } catch { }
    }
    public AxisAngleRotation3D Tilt = new AxisAngleRotation3D(new Vector3D(0,1,0),-22);
    public AxisAngleRotation3D Spin = new AxisAngleRotation3D(new Vector3D(0,0,1),0);
    private DiffuseMaterial sleeve;
    public void SetCover(ImageSource cover) {
        if(cover!=null) sleeve.Brush=new ImageBrush(cover){Stretch=Stretch.UniformToFill};
        else sleeve.Brush=DefaultSleeve();
    }
    private static Brush DefaultSleeve() {
        var group=new DrawingGroup();
        using(var c=group.Open()) {
            c.DrawRectangle(new LinearGradientBrush(Color.FromRgb(245,62,82),Color.FromRgb(82,12,30),45),null,new Rect(0,0,256,256));
            for(int i=0;i<7;i++) c.DrawEllipse(null,new Pen(new SolidColorBrush(Color.FromArgb(115,255,225,232)),3),new Point(180,175),35+i*14,35+i*14);
            c.DrawRectangle(new SolidColorBrush(Color.FromRgb(255,255,255)),null,new Rect(22,25,65,8));
            c.DrawRectangle(Brushes.White,null,new Rect(22,42,108,3));
        }
        return new DrawingBrush(group);
    }
    private static MeshGeometry3D Quad(double x,double y,double z,double w,double h) {
        return new MeshGeometry3D {
            Positions=new Point3DCollection{new Point3D(x,y,z),new Point3D(x+w,y,z),new Point3D(x+w,y+h,z),new Point3D(x,y+h,z)},
            TextureCoordinates=new PointCollection{new Point(0,1),new Point(1,1),new Point(1,0),new Point(0,0)},
            TriangleIndices=new Int32Collection{0,1,2,0,2,3}
        };
    }
    public DostScene(Viewport3D view) {
        view.Camera=new PerspectiveCamera(new Point3D(0,0,5),new Vector3D(0,0,-5),new Vector3D(0,1,0),36);
        var world=new Model3DGroup();
        world.Children.Add(new AmbientLight(Color.FromRgb(160,160,165)));
        world.Children.Add(new DirectionalLight(Colors.White,new Vector3D(-1,-2,-3)));
        var objects=new Model3DGroup();
        sleeve=new DiffuseMaterial(DefaultSleeve());
        var back=new GeometryModel3D(Quad(-1.05,-0.92,-0.18,1.65,1.85),sleeve);back.BackMaterial=sleeve;objects.Children.Add(back);
        var edge=new DiffuseMaterial(new SolidColorBrush(Color.FromRgb(66,20,29)));
        objects.Children.Add(new GeometryModel3D(new MeshGeometry3D {
            Positions=new Point3DCollection{new Point3D(-1.05,-0.92,-0.27),new Point3D(-1.05,-0.92,-0.18),new Point3D(-1.05,0.93,-0.18),new Point3D(-1.05,0.93,-0.27)},TriangleIndices=new Int32Collection{0,1,2,0,2,3}},edge));
        var art=new DrawingGroup();
        using(var c=art.Open()) {
            c.DrawEllipse(new RadialGradientBrush(Color.FromRgb(43,43,48),Color.FromRgb(8,8,11)),null,new Point(128,128),127,127);
            for(int i=0;i<14;i++) c.DrawEllipse(null,new Pen(new SolidColorBrush(Color.FromRgb(67,65,72)),0.65),new Point(128,128),58+i*4.6,58+i*4.6);
            c.DrawEllipse(new LinearGradientBrush(Color.FromRgb(255,72,95),Color.FromRgb(174,18,48),45),null,new Point(128,128),44,44);
            c.DrawRectangle(new SolidColorBrush(Color.FromRgb(255,230,235)),null,new Rect(105,110,46,4));
            c.DrawEllipse(Brushes.Black,null,new Point(128,128),6,6);
        }
        var material=new MaterialGroup();material.Children.Add(new DiffuseMaterial(new DrawingBrush(art)));material.Children.Add(new SpecularMaterial(new SolidColorBrush(Color.FromArgb(110,255,255,255)),65));
        var disc=new Model3DGroup();var mesh=new MeshGeometry3D();
        mesh.Positions.Add(new Point3D(0,0,0.09));mesh.TextureCoordinates.Add(new Point(0.5,0.5));
        const int segments=96;
        for(int i=0;i<=segments;i++){double a=i*Math.PI*2/segments;double x=Math.Cos(a),y=Math.Sin(a);mesh.Positions.Add(new Point3D(x,y,0.09));mesh.TextureCoordinates.Add(new Point(0.5+x*0.5,0.5-y*0.5));}
        for(int i=1;i<=segments;i++){mesh.TriangleIndices.Add(0);mesh.TriangleIndices.Add(i);mesh.TriangleIndices.Add(i+1);}
        var front=new GeometryModel3D(mesh,material);front.BackMaterial=material;disc.Children.Add(front);
        var rim=new MeshGeometry3D();
        for(int i=0;i<=segments;i++){double a=i*Math.PI*2/segments;rim.Positions.Add(new Point3D(Math.Cos(a),Math.Sin(a),0.09));rim.Positions.Add(new Point3D(Math.Cos(a),Math.Sin(a),-0.01));}
        for(int i=0;i<segments;i++){int n=i*2;foreach(int t in new int[]{n,n+1,n+2,n+2,n+1,n+3})rim.TriangleIndices.Add(t);}
        var rimModel=new GeometryModel3D(rim,new DiffuseMaterial(Brushes.DimGray));rimModel.BackMaterial=rimModel.Material;disc.Children.Add(rimModel);
        var discTransform=new Transform3DGroup();discTransform.Children.Add(new RotateTransform3D(Spin));discTransform.Children.Add(new TranslateTransform3D(0.42,-0.04,0.05));disc.Transform=discTransform;objects.Children.Add(disc);
        var transform=new Transform3DGroup();transform.Children.Add(new RotateTransform3D(new AxisAngleRotation3D(new Vector3D(1,0,0),13)));transform.Children.Add(new RotateTransform3D(Tilt));objects.Transform=transform;
        world.Children.Add(objects);view.Children.Add(new ModelVisual3D{Content=world});
    }
}
