using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows.Interop;

public sealed class MediaKeyEventArgs : EventArgs { public string Command {get;private set;} public MediaKeyEventArgs(string command){Command=command;} }
public sealed class AteshMediaKeys : IDisposable {
 [DllImport("user32.dll",SetLastError=true)] static extern bool RegisterHotKey(IntPtr window,int id,uint modifiers,uint key);
 [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr window,int id);
 private HwndSource source; private IntPtr handle;
 private readonly List<int> registered=new List<int>();
 private readonly Dictionary<int,string> commands=new Dictionary<int,string>{{0x4150,"toggle"},{0x4151,"next"},{0x4152,"previous"},{0x4153,"stop"}};
 public event EventHandler<MediaKeyEventArgs> Command;
 public int RegisteredCount {get{return registered.Count;}}
 public AteshMediaKeys(IntPtr window){
  handle=window;source=HwndSource.FromHwnd(window);source.AddHook(Hook);
  uint[] keys={0xB3,0xB0,0xB1,0xB2};
  for(int i=0;i<keys.Length;i++) if(RegisterHotKey(window,0x4150+i,0x4000,keys[i])) registered.Add(0x4150+i);
 }
 private IntPtr Hook(IntPtr hwnd,int message,IntPtr wparam,IntPtr lparam,ref bool handled){
  string command=null;
  if(message==0x312) commands.TryGetValue(wparam.ToInt32(),out command);
  if(message==0x319){int app=(int)((lparam.ToInt64()>>16)&0x7FF);int id=app==14?0x4150:app==11?0x4151:app==12?0x4152:app==13?0x4153:0;
   if(id!=0 && !registered.Contains(id)) commands.TryGetValue(id,out command);
  }
  if(command!=null){handled=true;var handler=Command;if(handler!=null)handler(this,new MediaKeyEventArgs(command));return new IntPtr(1);}
  return IntPtr.Zero;
 }
 public void Dispose(){foreach(int id in registered)UnregisterHotKey(handle,id);registered.Clear();if(source!=null){source.RemoveHook(Hook);source=null;}}
}
