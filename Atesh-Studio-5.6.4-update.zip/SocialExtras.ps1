﻿# Atesh Studio Social - Supabase anonymous presence
$script:supabaseUrl = 'https://xpvkhroksgmoibybxera.supabase.co'
$script:supabasePublishableKey = 'sb_publishable_tTh7HPuHNFRfUVW3VCgi-w_UuAKdUki'
$script:socialFile = Join-Path $script:dataDir 'social.json'
$script:socialState = @{
 Username=''; DeviceId=[Guid]::NewGuid().ToString(); Privacy='public';
 AccessToken=''; RefreshToken=''; UserId=''; ExpiresAt=''; LastTrackTitle=''; LastTrackArtist=''; Bio=''; AvatarUrl=''; LocalAvatarPath=''
}

try { Add-Type -AssemblyName System.Net.Http -ErrorAction SilentlyContinue } catch {}
if(-not $script:socialHttpClient){
 try {
  $script:socialHttpClient=[System.Net.Http.HttpClient]::new()
  $script:socialHttpClient.Timeout=[TimeSpan]::FromSeconds(3)
 } catch {$script:socialHttpClient=$null}
}
$script:socialPendingTitle=''
$script:socialPendingArtist=''
$script:socialDebounceTimer=$null

function Save-AteshSocialState {
 try {[IO.File]::WriteAllText($script:socialFile,($script:socialState|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($true))} catch {}
}
function Load-AteshSocialState {
 if(Test-Path -LiteralPath $script:socialFile){
  try {
   $o=Get-Content -LiteralPath $script:socialFile -Raw -Encoding UTF8 | ConvertFrom-Json
   foreach($k in @('Username','DeviceId','Privacy','AccessToken','RefreshToken','UserId','ExpiresAt','LastTrackTitle','LastTrackArtist','Bio','AvatarUrl','LocalAvatarPath')){
    if($o.PSObject.Properties[$k] -and $null -ne $o.$k){$script:socialState[$k]=[string]$o.$k}
   }
  } catch {}
 }
 if([string]::IsNullOrWhiteSpace($script:socialState.DeviceId)){$script:socialState.DeviceId=[Guid]::NewGuid().ToString()}
 if($script:socialState.Privacy -notin @('public','hidden')){$script:socialState.Privacy='public'}
}
function Get-SocialHeaders([bool]$auth=$false) {
 $h=@{apikey=$script:supabasePublishableKey;Accept='application/json'}
 if($auth -and $script:socialState.AccessToken){$h.Authorization='Bearer '+$script:socialState.AccessToken}
 return $h
}
function Invoke-SocialJson([string]$method,[string]$url,$body=$null,[bool]$auth=$false,$extraHeaders=$null) {
 $headers=Get-SocialHeaders $auth
 if($extraHeaders){foreach($k in $extraHeaders.Keys){$headers[$k]=$extraHeaders[$k]}}
 $args=@{Uri=$url;Method=$method;Headers=$headers;TimeoutSec=5;ErrorAction='Stop'}
 if($null -ne $body){$args.ContentType='application/json';$args.Body=($body|ConvertTo-Json -Depth 6 -Compress)}
 return Invoke-RestMethod @args
}
function Update-SocialTokens($r) {
 if($r.access_token){$script:socialState.AccessToken=[string]$r.access_token}
 elseif($r.session -and $r.session.access_token){$script:socialState.AccessToken=[string]$r.session.access_token}
 if($r.refresh_token){$script:socialState.RefreshToken=[string]$r.refresh_token}
 elseif($r.session -and $r.session.refresh_token){$script:socialState.RefreshToken=[string]$r.session.refresh_token}
 $u=if($r.user){$r.user}elseif($r.session -and $r.session.user){$r.session.user}else{$null}
 if($u -and $u.id){$script:socialState.UserId=[string]$u.id}
 $expires=if($r.expires_in){[int]$r.expires_in}elseif($r.session -and $r.session.expires_in){[int]$r.session.expires_in}else{3600}
 $script:socialState.ExpiresAt=(Get-Date).ToUniversalTime().AddSeconds([Math]::Max(60,$expires-60)).ToString('o')
 Save-AteshSocialState
}
function Ensure-SocialUsername {
 if(-not [string]::IsNullOrWhiteSpace($script:socialState.Username)){return}
 try {
  Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction SilentlyContinue
  $name=[Microsoft.VisualBasic.Interaction]::InputBox('Toplulukta görünecek adını seç. Daha sonra Topluluk ekranından değiştirebilirsin.','Atesh Studio · Topluluk','')
 } catch {$name=''}
 $name=([string]$name).Trim()
 if($name.Length -gt 32){$name=$name.Substring(0,32)}
 if([string]::IsNullOrWhiteSpace($name)){$name='Atesh-'+$script:socialState.DeviceId.Substring(0,6)}
 $script:socialState.Username=$name
 Save-AteshSocialState
}
function Ensure-AteshSocialSession {
 try {
  $valid=$false
  if($script:socialState.AccessToken -and $script:socialState.ExpiresAt){
   try{$valid=([datetime]$script:socialState.ExpiresAt -gt (Get-Date).ToUniversalTime().AddSeconds(30))}catch{}
  }
  if($valid){return $true}
  if($script:socialState.RefreshToken){
   try {
    $r=Invoke-SocialJson 'POST' ($script:supabaseUrl+'/auth/v1/token?grant_type=refresh_token') @{refresh_token=$script:socialState.RefreshToken} $false
    Update-SocialTokens $r
    if($script:socialState.AccessToken){return $true}
   } catch {}
  }
  $r=Invoke-SocialJson 'POST' ($script:supabaseUrl+'/auth/v1/signup') @{data=@{app='AteshStudio'}} $false
  Update-SocialTokens $r
  return -not [string]::IsNullOrWhiteSpace($script:socialState.AccessToken)
 } catch {return $false}
}
function Send-AteshSocialStatus([bool]$online=$true,[string]$title=$null,[string]$artist=$null) {
 try {
  Ensure-SocialUsername
  if(-not (Ensure-AteshSocialSession)){return $false}
  if($null -eq $title){$title=$script:socialState.LastTrackTitle}
  if($null -eq $artist){$artist=$script:socialState.LastTrackArtist}
  if($script:socialState.Privacy -eq 'hidden'){$online=$false;$title=$null;$artist=$null}
  $body=@{
   user_id=$script:socialState.UserId;device_id=$script:socialState.DeviceId;username=$script:socialState.Username;
   is_online=$online;track_title=$(if($online){$title}else{$null});artist=$(if($online){$artist}else{$null});
   privacy=$script:socialState.Privacy;last_seen=(Get-Date).ToUniversalTime().ToString('o')
  }
  # UI thread'i bekletmeden HTTP istegini arka planda baslat.
  if($script:socialHttpClient){
   $json=$body|ConvertTo-Json -Depth 6 -Compress
   $url=$script:supabaseUrl+'/rest/v1/user_status?on_conflict=user_id'
   $req=[System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post,$url)
   [void]$req.Headers.TryAddWithoutValidation('apikey',$script:supabasePublishableKey)
   [void]$req.Headers.TryAddWithoutValidation('Authorization','Bearer '+$script:socialState.AccessToken)
   [void]$req.Headers.TryAddWithoutValidation('Prefer','resolution=merge-duplicates,return=minimal')
   $req.Content=[System.Net.Http.StringContent]::new($json,[Text.Encoding]::UTF8,'application/json')
   [void]$script:socialHttpClient.SendAsync($req)
  } else {
   # Eski sistemlerde yedek yol. Normalde bu kola girilmez.
   $headers=@{Prefer='resolution=merge-duplicates,return=minimal'}
   [void](Invoke-SocialJson 'POST' ($script:supabaseUrl+'/rest/v1/user_status?on_conflict=user_id') $body $true $headers)
  }
  return $true
 } catch {return $false}
}
function Send-PendingAteshSocialTrack {
 try {
  if($script:socialDebounceTimer){$script:socialDebounceTimer.Stop()}
  [void](Send-AteshSocialStatus $true ([string]$script:socialPendingTitle) ([string]$script:socialPendingArtist))
 } catch {}
}
function Queue-AteshSocialTrackStatus([string]$title,[string]$artist) {
 $script:socialPendingTitle=[string]$title
 $script:socialPendingArtist=[string]$artist
 if(-not $script:socialDebounceTimer){
  $script:socialDebounceTimer=[Windows.Threading.DispatcherTimer]::new()
  $script:socialDebounceTimer.Interval=[TimeSpan]::FromMilliseconds(250)
  $script:socialDebounceTimer.Add_Tick({Send-PendingAteshSocialTrack})
 }
 $script:socialDebounceTimer.Stop();$script:socialDebounceTimer.Start()
}
function Set-AteshSocialTrack([string]$title,[string]$artist) {
 $script:socialState.LastTrackTitle=[string]$title;$script:socialState.LastTrackArtist=[string]$artist;Save-AteshSocialState
 # Hizli ileri/geri gecislerde sadece en son sarki gonderilir.
 Queue-AteshSocialTrackStatus $title $artist
}
function Get-AteshSocialUsers {
 try {
  if(-not (Ensure-AteshSocialSession)){return @()}
  $cutoff=(Get-Date).ToUniversalTime().AddSeconds(-90).ToString('o')
  $encoded=[Uri]::EscapeDataString($cutoff)
  $base=$script:supabaseUrl+'/rest/v1/user_status?'
  try {
   $url=$base+'select=user_id,username,track_title,artist,last_seen,privacy,bio,avatar_url&is_online=eq.true&privacy=eq.public&last_seen=gte.'+$encoded+'&order=last_seen.desc'
   return @(Invoke-SocialJson 'GET' $url $null $true)
  } catch {
   # V5.4 migration henuz calistirilmadiysa eski semayla Topluluk yine calissin.
   $url=$base+'select=user_id,username,track_title,artist,last_seen,privacy&is_online=eq.true&privacy=eq.public&last_seen=gte.'+$encoded+'&order=last_seen.desc'
   return @(Invoke-SocialJson 'GET' $url $null $true)
  }
 } catch {return @()}
}
function Set-AteshSocialProfile([string]$username,[string]$privacy) {
 $username=([string]$username).Trim();if($username.Length -gt 32){$username=$username.Substring(0,32)}
 if(-not [string]::IsNullOrWhiteSpace($username)){$script:socialState.Username=$username}
 if($privacy -in @('public','hidden')){$script:socialState.Privacy=$privacy}
 Save-AteshSocialState
 [void](Send-AteshSocialStatus $true)
}
function Initialize-AteshSocial {
 Load-AteshSocialState;Ensure-SocialUsername
 [void](Send-AteshSocialStatus $true '' '')
}
function Stop-AteshSocial {[void](Send-AteshSocialStatus $false)}

# --- V5.4 Social Profiles -------------------------------------------------
# These fields are public profile metadata only. Local file paths or audio files
# are never sent to Supabase.
if(-not $script:socialState.ContainsKey('Bio')){$script:socialState.Bio=''}
if(-not $script:socialState.ContainsKey('AvatarUrl')){$script:socialState.AvatarUrl=''}

function Save-AteshSocialProfileV54([string]$username,[string]$privacy,[string]$bio,[string]$avatarUrl) {
 try {
  $username=([string]$username).Trim();if($username.Length -gt 32){$username=$username.Substring(0,32)}
  $bio=([string]$bio).Trim();if($bio.Length -gt 160){$bio=$bio.Substring(0,160)}
  $avatarUrl=([string]$avatarUrl).Trim();if($avatarUrl.Length -gt 500){$avatarUrl=$avatarUrl.Substring(0,500)}
  if(-not [string]::IsNullOrWhiteSpace($username)){$script:socialState.Username=$username}
  if($privacy -in @('public','hidden')){$script:socialState.Privacy=$privacy}
  $script:socialState.Bio=$bio;$script:socialState.AvatarUrl=$avatarUrl
  Save-AteshSocialState
  if(Ensure-AteshSocialSession){
   try {
    $body=@{user_id=$script:socialState.UserId;device_id=$script:socialState.DeviceId;username=$script:socialState.Username;bio=$bio;avatar_url=$avatarUrl;privacy=$script:socialState.Privacy;is_online=$true;last_seen=(Get-Date).ToUniversalTime().ToString('o')}
    $headers=@{Prefer='resolution=merge-duplicates,return=minimal'}
    [void](Invoke-SocialJson 'POST' ($script:supabaseUrl+'/rest/v1/user_status?on_conflict=user_id') $body $true $headers)
   } catch {}
  }
  [void](Send-AteshSocialStatus $true $(if($script:current -and $script:playing){[string]$script:current.Title}else{''}) $(if($script:current -and $script:playing){[string]$script:current.Artist}else{''}))
  return $true
 } catch {return $false}
}

function Add-AteshListeningHistory([string]$title,[string]$artist) {
 try {
  if([string]::IsNullOrWhiteSpace($title)){return}
  if(-not (Ensure-AteshSocialSession)){return}
  $body=@{user_id=$script:socialState.UserId;track_title=[string]$title;artist=[string]$artist;played_at=(Get-Date).ToUniversalTime().ToString('o')}
  if($script:socialHttpClient){
   $json=$body|ConvertTo-Json -Compress
   $req=[System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post,($script:supabaseUrl+'/rest/v1/listening_history'))
   [void]$req.Headers.TryAddWithoutValidation('apikey',$script:supabasePublishableKey)
   [void]$req.Headers.TryAddWithoutValidation('Authorization','Bearer '+$script:socialState.AccessToken)
   [void]$req.Headers.TryAddWithoutValidation('Prefer','return=minimal')
   $req.Content=[System.Net.Http.StringContent]::new($json,[Text.Encoding]::UTF8,'application/json')
   [void]$script:socialHttpClient.SendAsync($req)
  }
 } catch {}
}

function Get-AteshRecentListening([int]$limit=12) {
 try {
  if(-not (Ensure-AteshSocialSession)){return @()}
  $limit=[Math]::Max(1,[Math]::Min(50,$limit))
  $uid=[Uri]::EscapeDataString($script:socialState.UserId)
  return @(Invoke-SocialJson 'GET' ($script:supabaseUrl+"/rest/v1/listening_history?select=track_title,artist,played_at&user_id=eq.$uid&order=played_at.desc&limit=$limit") $null $true)
 } catch {return @()}
}

function Find-AteshSocialUser([string]$username) {
 try {
  if(-not (Ensure-AteshSocialSession)){return $null}
  $name=([string]$username).Trim();if([string]::IsNullOrWhiteSpace($name)){return $null}
  $q=[Uri]::EscapeDataString($name)
  try{$rows=@(Invoke-SocialJson 'GET' ($script:supabaseUrl+"/rest/v1/user_status?select=user_id,username,bio,avatar_url&username=eq.$q&privacy=eq.public&limit=1") $null $true)}catch{$rows=@(Invoke-SocialJson 'GET' ($script:supabaseUrl+"/rest/v1/user_status?select=user_id,username&username=eq.$q&privacy=eq.public&limit=1") $null $true)}
  if($rows.Count -gt 0){return $rows[0]}
 } catch {}
 return $null
}

function Follow-AteshSocialUser([string]$targetUserId) {
 try {
  if(-not (Ensure-AteshSocialSession)){return $false}
  if([string]::IsNullOrWhiteSpace($targetUserId) -or $targetUserId -eq $script:socialState.UserId){return $false}
  $body=@{follower_id=$script:socialState.UserId;following_id=$targetUserId}
  $headers=@{Prefer='resolution=merge-duplicates,return=minimal'}
  [void](Invoke-SocialJson 'POST' ($script:supabaseUrl+'/rest/v1/user_follows?on_conflict=follower_id,following_id') $body $true $headers)
  return $true
 } catch {return $false}
}

function Unfollow-AteshSocialUser([string]$targetUserId) {
 try {
  if(-not (Ensure-AteshSocialSession)){return $false}
  $me=[Uri]::EscapeDataString($script:socialState.UserId);$target=[Uri]::EscapeDataString($targetUserId)
  [void](Invoke-SocialJson 'DELETE' ($script:supabaseUrl+"/rest/v1/user_follows?follower_id=eq.$me&following_id=eq.$target") $null $true)
  return $true
 } catch {return $false}
}

function Get-AteshFollowingUsers {
 try {
  if(-not (Ensure-AteshSocialSession)){return @()}
  $me=[Uri]::EscapeDataString($script:socialState.UserId)
  $links=@(Invoke-SocialJson 'GET' ($script:supabaseUrl+"/rest/v1/user_follows?select=following_id&follower_id=eq.$me") $null $true)
  $result=[System.Collections.ArrayList]::new()
  foreach($l in $links){
   try {
    $id=[Uri]::EscapeDataString([string]$l.following_id)
    try{$u=@(Invoke-SocialJson 'GET' ($script:supabaseUrl+"/rest/v1/user_status?select=user_id,username,bio,avatar_url,is_online,last_seen&user_id=eq.$id&limit=1") $null $true)}catch{$u=@(Invoke-SocialJson 'GET' ($script:supabaseUrl+"/rest/v1/user_status?select=user_id,username,is_online,last_seen&user_id=eq.$id&limit=1") $null $true)}
    if($u.Count -gt 0){[void]$result.Add($u[0])}
   } catch {}
  }
  return @($result)
 } catch {return @()}
}
