﻿param([switch]$SelfTest, [switch]$LoadOnly, [switch]$WaitForLauncher)
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Windows.Forms,System.Xaml
$ErrorActionPreference = 'Stop'
$script:homeDir = $PSScriptRoot
# Kisisel veriler uygulama surumlerinden bagimsiz, tek bir ortak klasorde tutulur.
$script:dataDir = Join-Path $env:LOCALAPPDATA 'AteshStudio'
if($LoadOnly -and $env:ATESH_VERIFY_DATA){$script:dataDir=$env:ATESH_VERIFY_DATA}
if(-not (Test-Path -LiteralPath $script:dataDir)){[void](New-Item -ItemType Directory -Path $script:dataDir -Force)}
$script:dataFile = Join-Path $script:dataDir 'kutuphane.json'
$script:settingsFile = Join-Path $script:dataDir 'ayarlar.json'
$script:appSettings = @{WatchFolders=@();AutoScan=$true;Theme='Atesh Dark'}
$script:appVersion = '5.6.0'
function Load-AppSettings {
 if(Test-Path -LiteralPath $script:settingsFile){
  try{$o=Get-Content -LiteralPath $script:settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
   $script:appSettings=@{WatchFolders=@($o.WatchFolders);AutoScan=if($null -eq $o.AutoScan){$true}else{[bool]$o.AutoScan};Theme=if($o.Theme){[string]$o.Theme}else{'Atesh Dark'}}
  }catch{}
 }
}
function Save-AppSettings {
 try{[IO.File]::WriteAllText($script:settingsFile,($script:appSettings|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($true))}catch{}
}
Load-AppSettings

# Ilk geciste eski uygulama klasorundeki veriyi ortak alana guvenle tasi.
# Hem ortak hem eski kutuphane varsa, daha fazla sarki iceren kutuphane korunur.
$script:migrationMarker = Join-Path $script:dataDir '.ortak-veri-v1'
if(-not (Test-Path -LiteralPath $script:migrationMarker)){
 function Get-AteshTrackCount([string]$file){
  if(-not (Test-Path -LiteralPath $file)){return -1}
  try{$obj=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json;return @($obj.Tracks).Count}catch{return -1}
 }
 $legacyLibrary=Join-Path $script:homeDir 'kutuphane.json'
 $legacyPlayback=Join-Path $script:homeDir 'oynatma.json'
 $legacyCovers=Join-Path $script:homeDir 'kapaklar'
 $sharedPlayback=Join-Path $script:dataDir 'oynatma.json'
 $sharedCovers=Join-Path $script:dataDir 'kapaklar'
 $legacyCount=Get-AteshTrackCount $legacyLibrary
 $sharedCount=Get-AteshTrackCount $script:dataFile
 if($legacyCount -gt $sharedCount){Copy-Item -LiteralPath $legacyLibrary -Destination $script:dataFile -Force}
 elseif($sharedCount -lt 0 -and $legacyCount -ge 0){Copy-Item -LiteralPath $legacyLibrary -Destination $script:dataFile -Force}
 if(-not (Test-Path -LiteralPath $sharedPlayback) -and (Test-Path -LiteralPath $legacyPlayback)){Copy-Item -LiteralPath $legacyPlayback -Destination $sharedPlayback -Force}
 if(Test-Path -LiteralPath $legacyCovers){
  if(-not (Test-Path -LiteralPath $sharedCovers)){[void](New-Item -ItemType Directory -Path $sharedCovers -Force)}
  Get-ChildItem -LiteralPath $legacyCovers -File -ErrorAction SilentlyContinue | ForEach-Object {if(-not (Test-Path -LiteralPath (Join-Path $sharedCovers $_.Name))){Copy-Item -LiteralPath $_.FullName -Destination $sharedCovers}}
 }
 [IO.File]::WriteAllText($script:migrationMarker,(Get-Date).ToString('o'),[Text.UTF8Encoding]::new($false))
}
$script:library = [System.Collections.ArrayList]::new()
$script:lists = [System.Collections.ArrayList]::new()
$script:current = $null
$script:playing = $false
$script:view = 'all'
$script:queue = @()
$script:shuffle = $false
$script:repeat = $false
$script:history = @()
$script:lastListenTick = [DateTime]::UtcNow
$script:coverCache = @{}
$script:shellMetadata = New-Object -ComObject Shell.Application
if(-not ('DostCover' -as [type])) {
 Add-Type -Path (Join-Path $homeDir 'MediaInfo.cs') -ReferencedAssemblies @('System.dll',[Windows.DependencyObject].Assembly.Location,[Windows.Media.Imaging.BitmapSource].Assembly.Location)
}
if(-not ('DostScene' -as [type])) {
 Add-Type -Path (Join-Path $homeDir 'Scene3D.cs') -ReferencedAssemblies @('System.dll',[Windows.DependencyObject].Assembly.Location,[Windows.Media.Imaging.BitmapSource].Assembly.Location,[Windows.Controls.Viewport3D].Assembly.Location,[System.Xaml.XamlReader].Assembly.Location)
}
function Read-MusicInfo([string]$path) {
 $title=[IO.Path]::GetFileNameWithoutExtension($path);$artist='Yerel müzik';$album=''
 if($title -match '^(.+?) - (.+)$'){$artist=$Matches[1];$title=$Matches[2]}
 if([IO.Path]::GetExtension($path) -ieq '.wav'){
  $waveTags=[DostCover]::ReadWaveTags($path)
  if($waveTags.ContainsKey('INAM')){$title=$waveTags['INAM']}
  if($waveTags.ContainsKey('IART')){$artist=$waveTags['IART']}
  if($waveTags.ContainsKey('IPRD')){$album=$waveTags['IPRD']}
 }
 try {
  $folder=$script:shellMetadata.Namespace([IO.Path]::GetDirectoryName($path))
  $item=$folder.ParseName([IO.Path]::GetFileName($path))
  $tagTitle=[string]$item.ExtendedProperty('System.Title')
  $tagArtist=@($item.ExtendedProperty('System.Music.Artist')) -join ', '
  $tagAlbum=[string]$item.ExtendedProperty('System.Music.AlbumTitle')
  if(-not [string]::IsNullOrWhiteSpace($tagAlbum)){$album=$tagAlbum}
  if(-not [string]::IsNullOrWhiteSpace($tagTitle)){$title=$tagTitle}
  if(-not [string]::IsNullOrWhiteSpace($tagArtist)){$artist=$tagArtist}
 } catch { } finally {
  if($item){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($item)}
  if($folder){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($folder)}
 }
 return @{Title=$title;Artist=$artist;Album=$album}
}
function Get-Cover([string]$path) {
 if([string]::IsNullOrWhiteSpace($path)){return $null}
 $track=$script:library | Where-Object Path -eq $path | Select-Object -First 1
 if($track -and $track.Cover){$custom=Read-CoverAsset $track.Cover;if($custom){return $custom}}
 if($script:coverCache.ContainsKey($path)){return $script:coverCache[$path]}
 $cover=$null
 if(Test-Path -LiteralPath $path){
  $cover=[DostCover]::Read($path)
  if(-not $cover){
   foreach($name in @('cover.jpg','cover.png','folder.jpg')){
    $candidate=Join-Path ([IO.Path]::GetDirectoryName($path)) $name
    if(Test-Path -LiteralPath $candidate){try{$cover=[Windows.Media.Imaging.BitmapImage]::new();$cover.BeginInit();$cover.CacheOption='OnLoad';$cover.UriSource=[Uri]::new($candidate);$cover.DecodePixelWidth=256;$cover.EndInit();$cover.Freeze();break}catch{$cover=$null}}
   }
  }
 }
 $script:coverCache[$path]=$cover
 return $cover
}
. (Join-Path $homeDir 'CollectionExtras.ps1')
. (Join-Path $homeDir 'SocialExtras.ps1')
[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" AllowDrop="True" Icon="{DynamicResource BrandIcon}" Title="Atesh studio" Width="1480" Height="900" MinWidth="1200" MinHeight="740" Background="#09090B" Foreground="#F5F5F7" WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display">
 <Window.Resources>
<DrawingImage x:Key="BrandIcon"><DrawingImage.Drawing><DrawingGroup><GeometryDrawing Brush="#F43F53"><GeometryDrawing.Geometry><RectangleGeometry Rect="0,0,32,32" RadiusX="7" RadiusY="7"/></GeometryDrawing.Geometry></GeometryDrawing><GeometryDrawing Brush="White" Geometry="M 7,25 L 14,6 L 19,6 L 12,25 Z M 18,12 L 26,25 L 20,25 L 15,19 Z"/></DrawingGroup></DrawingImage.Drawing></DrawingImage>
  <Style TargetType="Button">
   <Setter Property="Background" Value="#19191D"/><Setter Property="Foreground" Value="#E7E7EB"/><Setter Property="Padding" Value="14,10"/><Setter Property="Margin" Value="0,0,8,0"/><Setter Property="BorderBrush" Value="#303036"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Cursor" Value="Hand"/><Setter Property="FontSize" Value="12"/>
   <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="B" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="7" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="#FF5264"/></Trigger><Trigger Property="IsPressed" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.65"/></Trigger><Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="#FF5264"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value="0.35"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType="TextBox"><Setter Property="Background" Value="#131316"/><Setter Property="Foreground" Value="#F5F5F7"/><Setter Property="CaretBrush" Value="#F43F53"/><Setter Property="BorderBrush" Value="#303036"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="12,10"/><Setter Property="FontSize" Value="13"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TextBox"><Border x:Name="B" Background="{TemplateBinding Background}" CornerRadius="8" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}"><ScrollViewer x:Name="PART_ContentHost"/></Border><ControlTemplate.Triggers><Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="#FF5264"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
  <Style TargetType="ListBoxItem"><Setter Property="Foreground" Value="#F5F5F7"/><Setter Property="Padding" Value="10"/><Setter Property="Margin" Value="0,2"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border x:Name="Row" Background="Transparent" BorderThickness="1" BorderBrush="Transparent" CornerRadius="8" Padding="{TemplateBinding Padding}"><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Row" Property="Background" Value="#202024"/></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="Row" Property="Background" Value="#32171D"/><Setter TargetName="Row" Property="BorderBrush" Value="#78414A"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
  <Style TargetType="Slider"><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Slider"><Grid MinHeight="22"><Track x:Name="PART_Track"><Track.DecreaseRepeatButton><RepeatButton Command="Slider.DecreaseLarge" Focusable="False"><RepeatButton.Template><ControlTemplate TargetType="RepeatButton"><Border Height="3" Background="#F43F53" CornerRadius="1.5"/></ControlTemplate></RepeatButton.Template></RepeatButton></Track.DecreaseRepeatButton><Track.Thumb><Thumb Width="10" Height="10"><Thumb.Template><ControlTemplate TargetType="Thumb"><Ellipse Fill="#F5F5F7"/></ControlTemplate></Thumb.Template></Thumb></Track.Thumb><Track.IncreaseRepeatButton><RepeatButton Command="Slider.IncreaseLarge" Focusable="False"><RepeatButton.Template><ControlTemplate TargetType="RepeatButton"><Border Height="3" Background="#34343B" CornerRadius="1.5"/></ControlTemplate></RepeatButton.Template></RepeatButton></Track.IncreaseRepeatButton></Track></Grid></ControlTemplate></Setter.Value></Setter></Style>
  <Style TargetType="ScrollBar"><Setter Property="Width" Value="9"/><Setter Property="Background" Value="Transparent"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ScrollBar"><Grid Width="9" Background="Transparent"><Track x:Name="PART_Track" Orientation="Vertical" IsDirectionReversed="True"><Track.Thumb><Thumb><Thumb.Template><ControlTemplate TargetType="Thumb"><Border Margin="2,2" Background="#4A4A53" CornerRadius="2"/></ControlTemplate></Thumb.Template></Thumb></Track.Thumb><Track.DecreaseRepeatButton><RepeatButton Command="ScrollBar.PageUpCommand" Opacity="0" Focusable="False"/></Track.DecreaseRepeatButton><Track.IncreaseRepeatButton><RepeatButton Command="ScrollBar.PageDownCommand" Opacity="0" Focusable="False"/></Track.IncreaseRepeatButton></Track></Grid></ControlTemplate></Setter.Value></Setter></Style>
 </Window.Resources>
 <Grid Background="#09090B"><Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="96"/></Grid.RowDefinitions>
  <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="220"/><ColumnDefinition Width="*"/><ColumnDefinition Width="310"/></Grid.ColumnDefinitions>
   <Border Background="#0D0D10" BorderBrush="#25252B" BorderThickness="0,0,1,0" Padding="14,18,14,14"><DockPanel>
    <StackPanel DockPanel.Dock="Top">
     <StackPanel Orientation="Horizontal" Margin="2,2,0,0"><Border Width="32" Height="34" Background="#F43F53" CornerRadius="8"><Viewbox Margin="7"><Path Data="M 0,28 L 10,0 L 17,0 L 7,28 Z M 15,9 L 24,28 L 16,28 L 11,17 Z" Fill="White"/></Viewbox></Border><StackPanel Margin="9,-2,0,0"><TextBlock Text="Atesh" FontSize="22" FontWeight="Bold"/><TextBlock Text="s t u d i o" FontSize="9" Foreground="#9C9CA6" Margin="1,-2,0,0"/></StackPanel></StackPanel>
     <TextBlock Text="DİNLE • HİSSET • ÖZGÜR OL" FontSize="8" Foreground="#7E7E87" Margin="2,12,0,24"/>
     <TextBlock Text="KÜTÜPHANE" FontSize="10" Foreground="#909098" Margin="10,0,0,12"/>
     <Button x:Name="Home" Content="⌂    Ana Sayfa" HorizontalContentAlignment="Left" Margin="0,0,0,8" Background="#32171D"/>
     <Button x:Name="All" Content="♫    Tüm şarkılar" HorizontalContentAlignment="Left" Margin="0,0,0,8" Background="Transparent" BorderThickness="0"/>
     <Button x:Name="Artists" Content="♬    Sanatçılar" HorizontalContentAlignment="Left" Margin="0,0,0,8" Background="Transparent" BorderThickness="0"/>
     <Button x:Name="History" Content="↶    Son çalınanlar" HorizontalContentAlignment="Left" Margin="0,0,0,8" Background="Transparent" BorderThickness="0"/>
     <Button x:Name="Fav" Content="♡    Favoriler" HorizontalContentAlignment="Left" Margin="0,0,0,8" Background="Transparent" BorderThickness="0"/>
     <Button x:Name="Social" Content="◉    Topluluk" HorizontalContentAlignment="Left" Margin="0,0,0,24" Background="Transparent" BorderThickness="0"/>
     <TextBlock Text="ÇALMA LİSTELERİN" FontSize="10" Foreground="#909098" Margin="10,0,0,14"/>
    </StackPanel>
    <StackPanel DockPanel.Dock="Bottom">
     <TextBlock Text="Kendi seçkini oluştur" Foreground="#ABABB3" FontSize="11" Margin="0,0,0,8"/>
     <TextBox x:Name="ListName" Visibility="Collapsed" Height="38" ToolTip="Yeni liste adı" AutomationProperties.Name="Yeni liste adı"/>
     <Button x:Name="NewList" Content="+   Yeni çalma listesi" Margin="0,8,0,20"/>
     <Border BorderBrush="#29292F" BorderThickness="0,1,0,0" Padding="0,16,0,0"><StackPanel><TextBlock Text="●  Kişisel kütüphane" Foreground="#F43F53" FontSize="11"/><TextBlock Text="Dinle. Hisset. Özgür ol." Foreground="#909098" FontSize="10" Margin="13,5,0,0"/></StackPanel></Border>
    </StackPanel>
    <ListBox x:Name="Lists" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="48"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Width="40" Height="40" CornerRadius="9" Background="#25171D" BorderBrush="#4B2A34" BorderThickness="1" VerticalAlignment="Center"><Border.Effect><DropShadowEffect BlurRadius="8" ShadowDepth="2" Opacity="0.20"/></Border.Effect><Grid><TextBlock Text="♫" Foreground="#F43F53" HorizontalAlignment="Center" VerticalAlignment="Center" FontSize="16"/><Border Width="13" Height="13" CornerRadius="6.5" Background="#F43F53" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,-2,-2"><TextBlock Text="+" Foreground="White" FontSize="8" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border></Grid></Border><StackPanel Grid.Column="1" VerticalAlignment="Center"><TextBlock Text="{Binding}" FontSize="12" FontWeight="SemiBold" Foreground="#F3F3F5" TextTrimming="CharacterEllipsis"/><TextBlock Text="Kişisel çalma listesi" FontSize="9" Foreground="#81818B" Margin="0,4,0,0"/></StackPanel></Grid></DataTemplate></ListBox.ItemTemplate></ListBox>
   </DockPanel></Border>
   <Grid Grid.Column="1" Margin="18,16,16,12"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
     <Grid MaxWidth="520" HorizontalAlignment="Left" Width="460"><TextBox x:Name="Search" Height="38" ToolTip="Şarkı veya sanatçı ara" AutomationProperties.Name="Şarkı veya sanatçı ara" Padding="14,11"/><TextBlock Text="Şarkı veya sanatçı ara…" Margin="15,0" Foreground="#909098" VerticalAlignment="Center" IsHitTestVisible="False"><TextBlock.Style><Style TargetType="TextBlock"><Setter Property="Visibility" Value="Collapsed"/><Style.Triggers><DataTrigger Binding="{Binding Text, ElementName=Search}" Value=""><Setter Property="Visibility" Value="Visible"/></DataTrigger></Style.Triggers></Style></TextBlock.Style></TextBlock></Grid>
     <StackPanel Grid.Column="1" Orientation="Horizontal"><Button x:Name="ScanFolder" Content="⌕   Klasör tara" Margin="8,0,0,0" ToolTip="Bir müzik klasörünü tara, yeni şarkıları ekle ve taşınmış dosyaları eşleştir"/><Button x:Name="QueueToggle" Content="☷   Çalma kuyruğu" Margin="8,0,0,0"/><Button x:Name="Settings" Content="⚙" Width="42" Height="38" Padding="0" Margin="8,0,0,0" FontSize="15" ToolTip="Ayarlar ve veri konumu"/><Button x:Name="Import" Content="+   Müzik ekle" Background="#F43F53" Foreground="#FFFFFF" BorderThickness="0" FontWeight="SemiBold" Margin="12,0,0,0" Padding="20,11"/></StackPanel>
    </Grid>
    <Border Grid.Row="1" CornerRadius="12" Margin="0,14,0,14" BorderBrush="#393038" BorderThickness="1"><Border.Background><LinearGradientBrush StartPoint="0,0" EndPoint="1,0.8"><GradientStop Color="#18181D" Offset="0"/><GradientStop Color="#1C1015" Offset="0.6"/><GradientStop Color="#481621" Offset="1"/></LinearGradientBrush></Border.Background>
     <Grid Height="122" ClipToBounds="True"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="185"/></Grid.ColumnDefinitions>
      <TextBlock Grid.ColumnSpan="2" Text="ATESH" FontSize="102" FontWeight="ExtraBold" Foreground="#FFF4F6" Opacity="0.018" HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,8,24,0"/>
      <StackPanel Margin="24,7,0,7" VerticalAlignment="Center"><StackPanel Orientation="Horizontal"><Border Width="17" Height="2" Background="#F43F53" VerticalAlignment="Center" Margin="0,0,8,0"/><TextBlock Text="ATEŞ STUDIO • KİŞİSEL MÜZİK ALANIN" FontSize="9" Foreground="#FF7786" FontWeight="SemiBold"/></StackPanel><TextBlock Text="Dinle. Hisset. Özgür ol." FontSize="25" LineHeight="28" FontWeight="SemiBold" Margin="0,8,0,5"/><TextBlock Text="Kütüphanen, listelerin ve ritmin tek bir yerde." Foreground="#A9A7AF" FontSize="11" Margin="0,3,0,0"/><StackPanel Orientation="Horizontal" Margin="0,8,0,0"><TextBlock x:Name="LibraryStat" Text="0 şarkı" Foreground="#F5F5F7" FontWeight="SemiBold" FontSize="11"/><TextBlock Text="    /    " Foreground="#6B5D66"/><TextBlock x:Name="ListStat" Text="0 çalma listesi" Foreground="#B5B2BB" FontSize="11"/></StackPanel></StackPanel>
      <Grid Grid.Column="1" Margin="0,0,10,0" Visibility="Collapsed"><Ellipse Width="116" Height="10" Fill="#CC000000" VerticalAlignment="Bottom" Margin="0,0,0,20"><Ellipse.Effect><BlurEffect Radius="14"/></Ellipse.Effect></Ellipse><Viewport3D x:Name="RecordScene" ClipToBounds="False"/><Button x:Name="MotionToggle" Content="3D • Açık" FontSize="9" Padding="8,4" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,6,10" Background="#331B23" BorderBrush="#68404A" ToolTip="3D hareketini aç veya kapat" Visibility="Collapsed"/></Grid>
     </Grid>
    </Border>
    <Grid Grid.Row="2" Margin="0,0,0,10"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
     <Button x:Name="QuickAll" Grid.Column="0" Height="50" Margin="0,0,8,0" Padding="12,7" HorizontalContentAlignment="Left" Background="#151519" BorderBrush="#292930"><StackPanel><TextBlock Text="Tüm şarkılar" FontSize="11" FontWeight="SemiBold"/><TextBlock Text="Kütüphanenin tamamı" FontSize="8" Foreground="#7F7F88" Margin="0,3,0,0"/></StackPanel></Button>
     <Button x:Name="QuickHistory" Grid.Column="1" Height="50" Margin="0,0,8,0" Padding="12,7" HorizontalContentAlignment="Left" Background="#151519" BorderBrush="#292930"><StackPanel><TextBlock Text="Son çalınanlar" FontSize="11" FontWeight="SemiBold"/><TextBlock Text="Kaldığın yerden devam et" FontSize="8" Foreground="#7F7F88" Margin="0,3,0,0"/></StackPanel></Button>
     <Button x:Name="QuickFav" Grid.Column="2" Height="50" Margin="0" Padding="12,7" HorizontalContentAlignment="Left" Background="#1B1216" BorderBrush="#4D2931"><StackPanel><TextBlock Text="Favoriler" FontSize="11" FontWeight="SemiBold"/><TextBlock Text="Sevdiğin parçalar" FontSize="8" Foreground="#A77A83" Margin="0,3,0,0"/></StackPanel></Button>
    </Grid>
    <Grid x:Name="MainViewHeader" Grid.Row="3" Margin="0,0,0,9"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><DockPanel><Image x:Name="CollectionHeaderCover" Width="40" Height="40" Stretch="UniformToFill" Margin="0,0,10,0" Visibility="Collapsed"/><StackPanel><StackPanel Orientation="Horizontal"><Button x:Name="EntityBack" Content="‹" Width="30" Height="28" Padding="0" Margin="0,0,8,0" Visibility="Collapsed" ToolTip="Geri"/><TextBlock x:Name="Heading" Text="Ana Sayfa" FontSize="21" FontWeight="SemiBold"/><Border x:Name="ViewTypeBadge" Background="#25171D" CornerRadius="7" Padding="7,3" Margin="10,2,0,0" Visibility="Collapsed"><TextBlock x:Name="ViewTypeText" Text="ÇALMA LİSTESİ" Foreground="#F06A7B" FontSize="8" FontWeight="SemiBold"/></Border></StackPanel><TextBlock x:Name="Count" Text="0 öneri" Foreground="#909098" FontSize="10" Margin="0,4,0,0"/></StackPanel></DockPanel><TextBlock x:Name="ViewHint" Grid.Column="1" Text="Kütüphanen sana göre şekillenir" Foreground="#777781" FontSize="10" VerticalAlignment="Bottom"/></Grid>
    <Grid Grid.Row="4">
     <ScrollViewer x:Name="HomeDashboard" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" Background="Transparent">
      <StackPanel>
       <TextBlock Text="Akıllı listeler" FontSize="15" FontWeight="SemiBold" Margin="0,0,0,8"/>
       <Grid Margin="0,0,0,14"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <Button x:Name="SmartWeek" Grid.Column="0" Margin="0,0,8,0" Padding="10,8" HorizontalContentAlignment="Left"><StackPanel><TextBlock Text="Bu hafta" FontSize="10" FontWeight="SemiBold"/><TextBlock Text="En çok dinlediklerin" FontSize="8" Foreground="#8F8F99" Margin="0,3,0,0"/></StackPanel></Button>
        <Button x:Name="SmartForgotten" Grid.Column="1" Margin="0,0,8,0" Padding="10,8" HorizontalContentAlignment="Left"><StackPanel><TextBlock Text="Yeniden keşfet" FontSize="10" FontWeight="SemiBold"/><TextBlock Text="Uzun süredir dinlemediklerin" FontSize="8" Foreground="#8F8F99" Margin="0,3,0,0"/></StackPanel></Button>
        <Button x:Name="SmartNewest" Grid.Column="2" Margin="0,0,8,0" Padding="10,8" HorizontalContentAlignment="Left"><StackPanel><TextBlock Text="Son eklenenler" FontSize="10" FontWeight="SemiBold"/><TextBlock Text="Kütüphanenin yenileri" FontSize="8" Foreground="#8F8F99" Margin="0,3,0,0"/></StackPanel></Button>
        <Button x:Name="SmartFavMix" Grid.Column="3" Padding="10,8" HorizontalContentAlignment="Left"><StackPanel><TextBlock Text="Favori karışık" FontSize="10" FontWeight="SemiBold"/><TextBlock Text="Favorilerinden rastgele" FontSize="8" Foreground="#8F8F99" Margin="0,3,0,0"/></StackPanel></Button>
       </Grid>
       <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="Son çalınanlar" FontSize="17" FontWeight="SemiBold"/><Button x:Name="SeeHistory" Grid.Column="1" Content="Tümünü gör" Background="Transparent" BorderThickness="0" Foreground="#9A9AA4" FontSize="10" Padding="8,4" Margin="0"/></Grid>
       <ListBox x:Name="RecentShelf" Height="184" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Auto" ScrollViewer.VerticalScrollBarVisibility="Disabled" Margin="0,0,0,18"><ListBox.ItemsPanel><ItemsPanelTemplate><StackPanel Orientation="Horizontal"/></ItemsPanelTemplate></ListBox.ItemsPanel><ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0,0,10,0"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border x:Name="Card" Width="158" Background="#141418" BorderBrush="#292930" BorderThickness="1" CornerRadius="11" Padding="8" RenderTransformOrigin="0.5,0.5"><Border.RenderTransform><ScaleTransform ScaleX="1" ScaleY="1"/></Border.RenderTransform><Border.Effect><DropShadowEffect BlurRadius="12" ShadowDepth="3" Opacity="0.18"/></Border.Effect><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Card" Property="Background" Value="#1C1C21"/><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/><Setter TargetName="Card" Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1.025" ScaleY="1.025"/></Setter.Value></Setter></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></ListBox.ItemContainerStyle><ListBox.ItemTemplate><DataTemplate><StackPanel><Border Height="112" Background="{Binding CoverBrush}" CornerRadius="9" ClipToBounds="True"><Grid><TextBlock Text="{Binding Initial}" FontSize="24" FontWeight="SemiBold" Foreground="#F0C5CE" Opacity="0.92" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="UniformToFill"/><Border Width="38" Height="38" CornerRadius="19" Background="#EAF43F53" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,8,8"><Border.Style><Style TargetType="Border"><Setter Property="Opacity" Value="0"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="0.88" ScaleY="0.88"/></Setter.Value></Setter><Style.Triggers><DataTrigger Binding="{Binding IsMouseOver, RelativeSource={RelativeSource AncestorType=ListBoxItem}}" Value="True"><Setter Property="Opacity" Value="1"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1" ScaleY="1"/></Setter.Value></Setter></DataTrigger></Style.Triggers></Style></Border.Style><TextBlock Text="▶" Foreground="White" FontSize="15" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="2,0,0,0"/></Border></Grid></Border><TextBlock Text="{Binding Title}" Foreground="#F4F4F6" FontSize="12" FontWeight="SemiBold" Margin="1,8,1,0" TextWrapping="Wrap" TextTrimming="WordEllipsis" MaxHeight="32"/><TextBlock Text="{Binding Artist}" FontSize="9.5" Foreground="#94949E" Margin="1,3,1,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></ListBox.ItemTemplate></ListBox>
       <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="Senin için" FontSize="17" FontWeight="SemiBold"/><TextBlock Grid.Column="1" Text="Kütüphanenden seçildi" Foreground="#777781" FontSize="9" VerticalAlignment="Center"/></Grid>
       <ListBox x:Name="ForYouShelf" Height="184" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Auto" ScrollViewer.VerticalScrollBarVisibility="Disabled" Margin="0,0,0,18"><ListBox.ItemsPanel><ItemsPanelTemplate><StackPanel Orientation="Horizontal"/></ItemsPanelTemplate></ListBox.ItemsPanel><ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0,0,10,0"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border x:Name="Card" Width="158" Background="#141418" BorderBrush="#292930" BorderThickness="1" CornerRadius="11" Padding="8" RenderTransformOrigin="0.5,0.5"><Border.RenderTransform><ScaleTransform ScaleX="1" ScaleY="1"/></Border.RenderTransform><Border.Effect><DropShadowEffect BlurRadius="12" ShadowDepth="3" Opacity="0.18"/></Border.Effect><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Card" Property="Background" Value="#1C1C21"/><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/><Setter TargetName="Card" Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1.025" ScaleY="1.025"/></Setter.Value></Setter></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></ListBox.ItemContainerStyle><ListBox.ItemTemplate><DataTemplate><StackPanel><Border Height="112" Background="{Binding CoverBrush}" CornerRadius="9" ClipToBounds="True"><Grid><TextBlock Text="{Binding Initial}" FontSize="24" FontWeight="SemiBold" Foreground="#F0C5CE" Opacity="0.92" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="UniformToFill"/><Border Width="38" Height="38" CornerRadius="19" Background="#EAF43F53" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,8,8"><Border.Style><Style TargetType="Border"><Setter Property="Opacity" Value="0"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="0.88" ScaleY="0.88"/></Setter.Value></Setter><Style.Triggers><DataTrigger Binding="{Binding IsMouseOver, RelativeSource={RelativeSource AncestorType=ListBoxItem}}" Value="True"><Setter Property="Opacity" Value="1"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1" ScaleY="1"/></Setter.Value></Setter></DataTrigger></Style.Triggers></Style></Border.Style><TextBlock Text="▶" Foreground="White" FontSize="15" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="2,0,0,0"/></Border></Grid></Border><TextBlock Text="{Binding Title}" Foreground="#F4F4F6" FontSize="12" FontWeight="SemiBold" Margin="1,8,1,0" TextWrapping="Wrap" TextTrimming="WordEllipsis" MaxHeight="32"/><TextBlock Text="{Binding Artist}" FontSize="9.5" Foreground="#94949E" Margin="1,3,1,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></ListBox.ItemTemplate></ListBox>
       <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="Bu hafta en çok dinlediklerin" FontSize="17" FontWeight="SemiBold"/><TextBlock Grid.Column="1" Text="Son 7 gündeki oynatmalarına göre" Foreground="#777781" FontSize="9" VerticalAlignment="Center"/></Grid>
       <ListBox x:Name="TopShelf" Height="184" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Auto" ScrollViewer.VerticalScrollBarVisibility="Disabled" Margin="0,0,0,18"><ListBox.ItemsPanel><ItemsPanelTemplate><StackPanel Orientation="Horizontal"/></ItemsPanelTemplate></ListBox.ItemsPanel><ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0,0,10,0"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border x:Name="Card" Width="158" Background="#141418" BorderBrush="#292930" BorderThickness="1" CornerRadius="11" Padding="8" RenderTransformOrigin="0.5,0.5"><Border.RenderTransform><ScaleTransform ScaleX="1" ScaleY="1"/></Border.RenderTransform><Border.Effect><DropShadowEffect BlurRadius="12" ShadowDepth="3" Opacity="0.18"/></Border.Effect><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Card" Property="Background" Value="#1C1C21"/><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/><Setter TargetName="Card" Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1.025" ScaleY="1.025"/></Setter.Value></Setter></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></ListBox.ItemContainerStyle><ListBox.ItemTemplate><DataTemplate><StackPanel><Border Height="112" Background="{Binding CoverBrush}" CornerRadius="9" ClipToBounds="True"><Grid><TextBlock Text="{Binding Initial}" FontSize="24" FontWeight="SemiBold" Foreground="#F0C5CE" Opacity="0.92" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="UniformToFill"/><Border Width="38" Height="38" CornerRadius="19" Background="#EAF43F53" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,8,8"><Border.Style><Style TargetType="Border"><Setter Property="Opacity" Value="0"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="0.88" ScaleY="0.88"/></Setter.Value></Setter><Style.Triggers><DataTrigger Binding="{Binding IsMouseOver, RelativeSource={RelativeSource AncestorType=ListBoxItem}}" Value="True"><Setter Property="Opacity" Value="1"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1" ScaleY="1"/></Setter.Value></Setter></DataTrigger></Style.Triggers></Style></Border.Style><TextBlock Text="▶" Foreground="White" FontSize="15" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="2,0,0,0"/></Border></Grid></Border><TextBlock Text="{Binding Title}" Foreground="#F4F4F6" FontSize="12" FontWeight="SemiBold" Margin="1,8,1,0" TextWrapping="Wrap" TextTrimming="WordEllipsis" MaxHeight="32"/><TextBlock Text="{Binding Subtitle}" FontSize="9.5" Foreground="#94949E" Margin="1,3,1,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></ListBox.ItemTemplate></ListBox>
       <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="Son eklenenler" FontSize="17" FontWeight="SemiBold"/><TextBlock Grid.Column="1" Text="Kütüphanene yeni katılanlar" Foreground="#777781" FontSize="9" VerticalAlignment="Center"/></Grid>
       <ListBox x:Name="NewestShelf" Height="184" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Auto" ScrollViewer.VerticalScrollBarVisibility="Disabled" Margin="0,0,0,10"><ListBox.ItemsPanel><ItemsPanelTemplate><StackPanel Orientation="Horizontal"/></ItemsPanelTemplate></ListBox.ItemsPanel><ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0,0,10,0"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border x:Name="Card" Width="158" Background="#141418" BorderBrush="#292930" BorderThickness="1" CornerRadius="11" Padding="8" RenderTransformOrigin="0.5,0.5"><Border.RenderTransform><ScaleTransform ScaleX="1" ScaleY="1"/></Border.RenderTransform><Border.Effect><DropShadowEffect BlurRadius="12" ShadowDepth="3" Opacity="0.18"/></Border.Effect><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Card" Property="Background" Value="#1C1C21"/><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/><Setter TargetName="Card" Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1.025" ScaleY="1.025"/></Setter.Value></Setter></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="Card" Property="BorderBrush" Value="#F43F53"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></ListBox.ItemContainerStyle><ListBox.ItemTemplate><DataTemplate><StackPanel><Border Height="112" Background="{Binding CoverBrush}" CornerRadius="9" ClipToBounds="True"><Grid><TextBlock Text="{Binding Initial}" FontSize="24" FontWeight="SemiBold" Foreground="#F0C5CE" Opacity="0.92" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="UniformToFill"/><Border Width="38" Height="38" CornerRadius="19" Background="#EAF43F53" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,8,8"><Border.Style><Style TargetType="Border"><Setter Property="Opacity" Value="0"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="0.88" ScaleY="0.88"/></Setter.Value></Setter><Style.Triggers><DataTrigger Binding="{Binding IsMouseOver, RelativeSource={RelativeSource AncestorType=ListBoxItem}}" Value="True"><Setter Property="Opacity" Value="1"/><Setter Property="RenderTransform"><Setter.Value><ScaleTransform ScaleX="1" ScaleY="1"/></Setter.Value></Setter></DataTrigger></Style.Triggers></Style></Border.Style><TextBlock Text="▶" Foreground="White" FontSize="15" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="2,0,0,0"/></Border></Grid></Border><TextBlock Text="{Binding Title}" Foreground="#F4F4F6" FontSize="12" FontWeight="SemiBold" Margin="1,8,1,0" TextWrapping="Wrap" TextTrimming="WordEllipsis" MaxHeight="32"/><TextBlock Text="{Binding Artist}" FontSize="9.5" Foreground="#94949E" Margin="1,3,1,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></ListBox.ItemTemplate></ListBox>
      </StackPanel>
     </ScrollViewer>
     <Border x:Name="EntityBrowser" Background="#101013" CornerRadius="12" BorderBrush="#27272D" BorderThickness="1" Padding="12" Visibility="Collapsed">
      <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
       <DockPanel Margin="8,2,8,12"><TextBlock x:Name="EntityBrowserTitle" Text="Sanatçılar" FontSize="16" FontWeight="SemiBold"/><TextBlock x:Name="EntityBrowserHint" DockPanel.Dock="Right" Text="Detay için çift tıkla" Foreground="#777781" FontSize="9" VerticalAlignment="Center"/></DockPanel>
       <ListBox x:Name="EntityList" Grid.Row="1" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemsPanel><ItemsPanelTemplate><WrapPanel/></ItemsPanelTemplate></ListBox.ItemsPanel><ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="5"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border x:Name="EntityCard" Width="180" Height="104" Background="#151519" BorderBrush="#292930" BorderThickness="1" CornerRadius="11" Padding="12"><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="EntityCard" Property="Background" Value="#1D1D22"/><Setter TargetName="EntityCard" Property="BorderBrush" Value="#F43F53"/></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="EntityCard" Property="BorderBrush" Value="#F43F53"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></ListBox.ItemContainerStyle><ListBox.ItemTemplate><DataTemplate><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="64"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Width="54" Height="54" CornerRadius="10" Background="{Binding Brush}" VerticalAlignment="Center"><TextBlock Text="{Binding Initial}" FontSize="22" FontWeight="SemiBold" Foreground="#F3CAD2" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><StackPanel Grid.Column="1" VerticalAlignment="Center" Margin="8,0,0,0"><TextBlock Text="{Binding Name}" FontSize="12.5" FontWeight="SemiBold" TextWrapping="Wrap" MaxHeight="38"/><TextBlock Text="{Binding Meta}" Foreground="#92929C" FontSize="9.5" Margin="0,5,0,0"/><TextBlock Text="{Binding Plays}" Foreground="#6F6F79" FontSize="8.5" Margin="0,3,0,0"/></StackPanel></Grid></DataTemplate></ListBox.ItemTemplate></ListBox>
      </Grid>
     </Border>
     <Border x:Name="SocialPanel" Background="#0D0D10" CornerRadius="14" BorderBrush="#29292F" BorderThickness="1" Padding="18" Visibility="Collapsed">
      <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
       <Grid Margin="2,0,2,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <StackPanel><TextBlock Text="Topluluk" FontSize="21" FontWeight="SemiBold"/><TextBlock x:Name="SocialCount" Text="Bağlanıyor…" Foreground="#92929C" FontSize="10.5" Margin="0,5,0,0"/></StackPanel>
        <Button x:Name="SocialRefresh" Grid.Column="1" Content="↻  Yenile" Padding="12,7" VerticalAlignment="Center"/>
       </Grid>
       <Border Grid.Row="1" Background="#121216" BorderBrush="#26262C" BorderThickness="1" CornerRadius="11" Padding="5" Margin="0,14,0,14" HorizontalAlignment="Left">
        <StackPanel Orientation="Horizontal"><Button x:Name="SocialLiveTab" Content="●  Canlı" Background="#3A171F" BorderBrush="#F43F53" BorderThickness="1" Padding="15,7"/><Button x:Name="SocialProfileTab" Content="Profilim" Padding="15,7" Margin="4,0,0,0"/><Button x:Name="SocialFollowingTab" Content="Takip" Padding="15,7" Margin="4,0,0,0"/></StackPanel>
       </Border>
       <Grid Grid.Row="2">
        <Grid x:Name="SocialLiveView"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
         <Border Background="#131318" BorderBrush="#2B2B32" BorderThickness="1" CornerRadius="12" Padding="13" Margin="0,0,0,14"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="165"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Topluluk profili" Foreground="#8F8F99" FontSize="9.5" Margin="2,0,0,5"/><TextBox x:Name="SocialUsername" Height="36" ToolTip="Toplulukta görünen adın"/></StackPanel><StackPanel Grid.Column="1" Margin="10,0,0,0"><TextBlock Text="Görünürlük" Foreground="#8F8F99" FontSize="9.5" Margin="2,0,0,5"/><ComboBox x:Name="SocialPrivacy" Height="36" Background="#151519" Foreground="#F5F5F7"><ComboBoxItem Content="Herkese açık"/><ComboBoxItem Content="Gizli mod"/></ComboBox></StackPanel><Button x:Name="SocialSave" Grid.Column="2" Content="Kaydet" Margin="10,20,0,0" Padding="15,7" Height="36"/></Grid></Border>
         <Grid Grid.Row="1"><ListBox x:Name="SocialUsers" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><Border Background="#141419" BorderBrush="#292930" BorderThickness="1" CornerRadius="12" Padding="14" Margin="0,0,0,9"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="70"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><Border Width="58" Height="58" CornerRadius="29" Background="#351820" ClipToBounds="True" VerticalAlignment="Center"><Grid><TextBlock Text="{Binding Initial}" Foreground="#F08A9A" FontSize="18" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding AvatarUrl}" Stretch="UniformToFill"/></Grid></Border><StackPanel Grid.Column="1" VerticalAlignment="Center"><TextBlock Text="{Binding Username}" FontSize="14.5" FontWeight="SemiBold"/><TextBlock Text="{Binding Bio}" Foreground="#777781" FontSize="9.5" Margin="0,3,0,0" TextTrimming="CharacterEllipsis"/><Border Background="#20161A" BorderBrush="#3B2229" BorderThickness="1" CornerRadius="8" Padding="9,6" Margin="0,8,18,0"><StackPanel><TextBlock Text="{Binding ActivityLabel}" Foreground="#F06A7D" FontSize="8.5" FontWeight="SemiBold"/><TextBlock Text="{Binding TrackText}" Foreground="#E2E2E7" FontSize="10.5" FontWeight="SemiBold" Margin="0,3,0,0" TextTrimming="CharacterEllipsis" TextWrapping="NoWrap" ToolTip="{Binding TrackText}"/></StackPanel></Border></StackPanel><Border Grid.Column="2" Background="#24151A" BorderBrush="#5B222D" BorderThickness="1" CornerRadius="9" Padding="9,5" VerticalAlignment="Center"><TextBlock Text="● CANLI" Foreground="#F43F53" FontSize="9" FontWeight="SemiBold"/></Border></Grid></Border></DataTemplate></ListBox.ItemTemplate></ListBox><TextBlock x:Name="SocialEmpty" Text="Şu anda görünür aktif kullanıcı yok." Foreground="#8F8F99" HorizontalAlignment="Center" VerticalAlignment="Center" FontSize="13"/></Grid>
        </Grid>
        <Grid x:Name="SocialProfileView" Visibility="Collapsed"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="290"/></Grid.ColumnDefinitions>
         <Border Background="#141419" BorderBrush="#292930" BorderThickness="1" CornerRadius="13" Padding="11" Margin="0,0,14,0"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
          <Border Background="#19191F" BorderBrush="#32323A" BorderThickness="1" CornerRadius="12" Padding="7" Margin="0,0,0,5"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="56"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><Grid Width="48" Height="48" VerticalAlignment="Center"><Border Width="46" Height="46" CornerRadius="23" Background="#351820" ClipToBounds="True" HorizontalAlignment="Left" VerticalAlignment="Center"><Grid><TextBlock x:Name="ProfilePreviewInitial" Text="A" Foreground="#F08A9A" FontSize="17" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image x:Name="ProfilePreviewAvatar" Stretch="UniformToFill"/></Grid></Border><Border Width="12" Height="12" CornerRadius="6" Background="#F43F53" BorderBrush="#19191F" BorderThickness="3" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,1,1"/></Grid><StackPanel Grid.Column="1" VerticalAlignment="Center" Margin="0,0,10,0"><TextBlock x:Name="ProfilePreviewUsername" Text="Atesh" FontSize="14.5" FontWeight="SemiBold" TextTrimming="CharacterEllipsis"/><TextBlock x:Name="ProfilePreviewBio" Text="Profiline kısa bir durum ekle." Foreground="#8F8F99" FontSize="9" Margin="0,2,0,0" TextTrimming="CharacterEllipsis"/><StackPanel Orientation="Horizontal" Margin="0,3,0,0"><TextBlock Text="●" Foreground="#F43F53" FontSize="7.5" VerticalAlignment="Center" Margin="0,0,5,0"/><TextBlock x:Name="ProfilePreviewTrack" Text="Şu an müzik çalmıyor" Foreground="#D8D8DE" FontSize="8.8" TextTrimming="CharacterEllipsis" MaxWidth="360"/></StackPanel></StackPanel><Border Grid.Column="2" Background="#24151A" BorderBrush="#4A252E" BorderThickness="1" CornerRadius="7" Padding="7,3" VerticalAlignment="Top"><TextBlock x:Name="ProfilePrivacyBadge" Text="Herkese açık" Foreground="#D9A0AB" FontSize="8.5"/></Border></Grid></Border>
          <TextBlock Grid.Row="1" Text="Profili düzenle" FontSize="14.5" FontWeight="SemiBold" Margin="0,0,0,3"/>
          <Grid Grid.Row="2"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="190"/></Grid.ColumnDefinitions>
           <StackPanel Margin="0,0,10,0"><TextBlock Text="Kullanıcı adı" Foreground="#8F8F99" FontSize="8.8" Margin="0,0,0,3"/><TextBox x:Name="ProfileUsername" Height="31"/></StackPanel>
           <StackPanel Grid.Column="1"><TextBlock Text="Gizlilik" Foreground="#8F8F99" FontSize="8.8" Margin="0,0,0,3"/><ComboBox x:Name="ProfilePrivacy" Height="31"><ComboBoxItem Content="Herkese açık"/><ComboBoxItem Content="Gizli mod"/></ComboBox></StackPanel>
          </Grid>
          <Grid Grid.Row="3" Margin="0,5,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="46*"/><ColumnDefinition Width="54*"/></Grid.ColumnDefinitions>
           <StackPanel Margin="0,0,10,0"><TextBlock Text="Durum / bio" Foreground="#8F8F99" FontSize="8.8" Margin="0,0,0,3"/><TextBox x:Name="ProfileBio" Height="38" TextWrapping="Wrap" AcceptsReturn="True" MaxLength="160"/></StackPanel>
           <StackPanel Grid.Column="1"><TextBlock Text="Profil resmi" Foreground="#8F8F99" FontSize="8.8" Margin="0,0,0,3"/><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="118"/><ColumnDefinition Width="72"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Button x:Name="ProfileAvatarChoose" Content="Fotoğraf seç" Height="30" Padding="9,3"/><Button x:Name="ProfileAvatarClear" Grid.Column="1" Content="Temizle" Height="30" Margin="6,0,0,0" Padding="7,3"/><TextBox x:Name="ProfileAvatarUrl" Grid.Column="2" Visibility="Collapsed" Width="0" Height="0" IsTabStop="False"/></Grid></StackPanel>
          </Grid>
          <Button x:Name="ProfileSave" Grid.Row="4" Content="Profili kaydet" Background="#F43F53" Foreground="White" BorderBrush="#F43F53" BorderThickness="1" Height="32" Margin="0,5,0,0" Padding="14,4" HorizontalAlignment="Stretch"/>
         </Grid></Border>
         <StackPanel Grid.Column="1" VerticalAlignment="Top">
          <Border Height="86" Background="#141419" BorderBrush="#292930" BorderThickness="1" CornerRadius="12" Padding="14" Margin="0,0,0,10"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="TAKİP EDİLEN" Foreground="#777781" FontSize="8.5" FontWeight="SemiBold"/><TextBlock Text="Topluluk bağlantıların" Foreground="#686873" FontSize="8.5" Margin="0,5,0,0"/></StackPanel><StackPanel Grid.Column="1" HorizontalAlignment="Right"><TextBlock x:Name="ProfileFollowingCount" Text="0" FontSize="24" FontWeight="SemiBold" HorizontalAlignment="Right"/><TextBlock Text="profil" Foreground="#8F8F99" FontSize="9" HorizontalAlignment="Right"/></StackPanel></Grid></Border>
          <Border Height="86" Background="#141419" BorderBrush="#292930" BorderThickness="1" CornerRadius="12" Padding="14"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="DURUM" Foreground="#777781" FontSize="8.5" FontWeight="SemiBold"/><TextBlock Text="Canlı görünürlük" Foreground="#686873" FontSize="8.5" Margin="0,5,0,0"/></StackPanel><TextBlock x:Name="ProfileStatusText" Grid.Column="1" Text="Çevrimiçi" Foreground="#F43F53" FontSize="14" FontWeight="SemiBold" VerticalAlignment="Center" HorizontalAlignment="Right"/></Grid></Border>
         </StackPanel>
        </Grid>
        <Grid x:Name="SocialFollowingView" Visibility="Collapsed"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
         <Border Background="#141419" BorderBrush="#292930" BorderThickness="1" CornerRadius="12" Padding="14" Margin="0,0,0,14"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Kullanıcı bul" FontSize="13" FontWeight="SemiBold"/><TextBlock Text="Kullanıcı adını yazarak yeni profilleri takip et." Foreground="#777781" FontSize="9.5" Margin="0,3,0,8"/><TextBox x:Name="FollowUsername" Height="36" ToolTip="Takip etmek istediğin kullanıcı adını yaz"/></StackPanel><Button x:Name="FollowAdd" Grid.Column="1" Content="＋  Takip et" Margin="10,28,0,0" Padding="14,7" Height="36"/><TextBlock x:Name="FollowStatus" Grid.ColumnSpan="2" VerticalAlignment="Bottom" Foreground="#8F8F99" FontSize="9" Margin="0,90,0,-18"/></Grid></Border>
         <Grid Grid.Row="1"><ListBox x:Name="FollowingUsers" Background="Transparent" BorderThickness="0"><ListBox.ItemTemplate><DataTemplate><Border Background="#141419" BorderBrush="#292930" BorderThickness="1" CornerRadius="12" Padding="13" Margin="0,0,0,8"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="58"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><Border Width="46" Height="46" CornerRadius="23" Background="#351820" ClipToBounds="True"><Grid><TextBlock Text="{Binding Initial}" Foreground="#F08A9A" FontSize="15" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding AvatarUrl}" Stretch="UniformToFill"/></Grid></Border><StackPanel Grid.Column="1" VerticalAlignment="Center"><TextBlock Text="{Binding Username}" FontSize="13" FontWeight="SemiBold"/><TextBlock Text="{Binding Bio}" Foreground="#8F8F99" FontSize="9.5" Margin="0,4,0,0" TextTrimming="CharacterEllipsis"/></StackPanel><Button Grid.Column="2" Content="Takibi bırak" Tag="{Binding UserId}" Padding="11,6" VerticalAlignment="Center"/></Grid></Border></DataTemplate></ListBox.ItemTemplate></ListBox><TextBlock x:Name="FollowingEmpty" Text="Henüz kimseyi takip etmiyorsun.&#10;Yukarıdan bir kullanıcı adı aratarak başlayabilirsin." TextAlignment="Center" Foreground="#8F8F99" HorizontalAlignment="Center" VerticalAlignment="Center" FontSize="12"/></Grid>
        </Grid>
       </Grid>
      </Grid>
     </Border>
     <Border x:Name="LibraryPanel" Background="#101013" CornerRadius="12" BorderBrush="#27272D" BorderThickness="1" Padding="12" Visibility="Collapsed"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="28"/><RowDefinition Height="*"/></Grid.RowDefinitions><WrapPanel x:Name="HistoryFilterBar" Visibility="Collapsed" Margin="8,0,8,10"><Button x:Name="HistToday" Content="Bugün" Padding="10,5"/><Button x:Name="HistYesterday" Content="Dün" Padding="10,5"/><Button x:Name="HistWeek" Content="Bu hafta" Padding="10,5"/><Button x:Name="Hist30" Content="Son 30 gün" Padding="10,5" Background="#32171D"/></WrapPanel><Grid Grid.Row="1" Margin="14,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="80"/></Grid.ColumnDefinitions><TextBlock Text="ŞARKI / SANATÇI" Foreground="#92929D" FontSize="9"/><TextBlock Grid.Column="1" Text="FAVORİ" Foreground="#92929D" FontSize="9" HorizontalAlignment="Right"/></Grid><ListBox x:Name="Tracks" Grid.Row="2" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="52"/><ColumnDefinition Width="*"/><ColumnDefinition Width="55"/></Grid.ColumnDefinitions><Border Background="#2D2025" CornerRadius="8" Width="38" Height="38" HorizontalAlignment="Left"><Grid><TextBlock Text="♫" FontSize="21" Foreground="#F43F53" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="UniformToFill"/></Grid></Border><StackPanel Grid.Column="1" VerticalAlignment="Center"><TextBlock Text="{Binding Title}" FontSize="13" FontWeight="SemiBold" TextTrimming="CharacterEllipsis"/><TextBlock Text="{Binding Subtitle}" Foreground="#9D9DA7" Margin="0,3,0,0" FontSize="11" TextTrimming="CharacterEllipsis"/></StackPanel><TextBlock Grid.Column="2" Text="{Binding Mark}" Foreground="#F43F53" FontSize="18" VerticalAlignment="Center" HorizontalAlignment="Right"/></Grid></DataTemplate></ListBox.ItemTemplate></ListBox><TextBlock x:Name="Empty" Grid.Row="2" TextAlignment="Center" Foreground="#B1B1BA" VerticalAlignment="Center" FontSize="14" LineHeight="26" TextWrapping="Wrap" Margin="12"/></Grid></Border>
    </Grid>
    <StackPanel x:Name="ActionBar" Grid.Row="5" Margin="0,10,0,0" Visibility="Collapsed"><WrapPanel><Button x:Name="PlaySelected" Content="▶   Şarkıyı çal" Background="#F43F53" Foreground="#FFFFFF" BorderThickness="0"/><Button x:Name="Favorite" Content="♡   Favoriye ekle"/><Button x:Name="TrackCover" Content="Kapak ▾"/><Button x:Name="Enqueue" Content="+   Kuyruğa ekle"/><Button x:Name="AddList" Content="+   Listeye ekle"/><Button x:Name="EditList" Content="Listeyi düzenle"/><Button x:Name="RemoveList" Content="Listeden çıkar"/></WrapPanel><TextBlock x:Name="Status" Text="İlk şarkını ekle, kendi kütüphaneni oluştur." Foreground="#909098" FontSize="11" TextWrapping="Wrap" Margin="0,9,0,0"/></StackPanel>
   </Grid>
   <Border Grid.Column="2" Background="#0D0D10" BorderBrush="#25252B" BorderThickness="1,0,0,0" Padding="14,16,14,12">
    <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
     <Grid Margin="0,0,0,8" Height="8"/>
     <Border Grid.Row="1" Height="224" Background="#17171C" CornerRadius="16" BorderBrush="#32323A" BorderThickness="1" ClipToBounds="True"><Grid><Border x:Name="SideNowFallback" Background="#251A1F"><Grid><TextBlock x:Name="SideNowInitial" Text="A" FontSize="68" FontWeight="Bold" Foreground="#E7B4C0" HorizontalAlignment="Center" VerticalAlignment="Center"/></Grid></Border><Image x:Name="SideNowCover" Stretch="UniformToFill"/></Grid></Border>
     <StackPanel Grid.Row="2" Margin="2,18,2,0"><TextBlock x:Name="SideNowTitle" Text="Sahne senin." FontSize="17.5" FontWeight="SemiBold" TextWrapping="Wrap" MaxHeight="48"/><TextBlock x:Name="SideNowArtist" Text="Atesh studio" Foreground="#B0B0B9" FontSize="12.5" Margin="0,8,0,0" TextTrimming="CharacterEllipsis"/><TextBlock x:Name="SideNowMeta" Text="Kütüphanenden bir şarkı seç." Foreground="#73737D" FontSize="10" Margin="0,8,0,0"/><StackPanel Orientation="Horizontal" Margin="0,13,0,0"><Button x:Name="SideFavorite" Content="♡" Width="44" Height="38" Padding="0" FontSize="15" ToolTip="Favoriye ekle veya çıkar"/><Button x:Name="SideAddList" Content="＋" Width="44" Height="38" Padding="0" FontSize="14" ToolTip="Listeye ekle"/><Button x:Name="SideQueueOpen" Content="☷" Width="44" Height="38" Padding="0" FontSize="14" ToolTip="Çalma kuyruğu"/></StackPanel></StackPanel>
     <Border Grid.Row="3" Margin="0,14,0,12" Height="1" Background="#27272D"/>
     <Grid Grid.Row="4"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><DockPanel Margin="0,0,0,8"><TextBlock Text="SIRADAKİ" FontSize="10" Foreground="#A7A7B0" FontWeight="SemiBold"/><TextBlock x:Name="SideQueueCount" DockPanel.Dock="Right" Text="0 parça" Foreground="#6F6F79" FontSize="10"/></DockPanel><ListBox x:Name="SideQueue" Grid.Row="1" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><Grid Margin="0,9"><Grid.ColumnDefinitions><ColumnDefinition Width="48"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Width="40" Height="40" CornerRadius="6" Background="#24191E" ClipToBounds="True"><Grid><TextBlock Text="{Binding Initial}" FontSize="12" Foreground="#B55A6B" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="UniformToFill"/></Grid></Border><StackPanel Grid.Column="1" VerticalAlignment="Center"><TextBlock Text="{Binding Label}" FontSize="12" FontWeight="SemiBold" TextTrimming="CharacterEllipsis"/><TextBlock Text="{Binding Artist}" FontSize="10" Foreground="#8F8F99" Margin="0,3,0,0" TextTrimming="CharacterEllipsis"/></StackPanel></Grid></DataTemplate></ListBox.ItemTemplate></ListBox></Grid>
    </Grid>
   </Border>
  </Grid>
  <Border Grid.Row="1" Background="#101013" BorderBrush="#2B2B31" BorderThickness="0,1,0,0" Padding="16,8"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="260"/><ColumnDefinition Width="*"/><ColumnDefinition Width="185"/></Grid.ColumnDefinitions>
   <Grid VerticalAlignment="Center"><Grid.ColumnDefinitions><ColumnDefinition Width="54"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Width="52" Height="52" CornerRadius="9" Background="#2B1C22" HorizontalAlignment="Left" ClipToBounds="True"><Grid><Border x:Name="NowFallback" Background="#251A1F"><TextBlock x:Name="NowInitial" Text="A" FontSize="22" FontWeight="Bold" Foreground="#E7B4C0" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><Image x:Name="NowCover" Stretch="UniformToFill"/></Grid></Border><StackPanel Grid.Column="1" VerticalAlignment="Center" Margin="0,0,12,0"><TextBlock x:Name="NowTitle" Text="Sahne senin." FontSize="13" FontWeight="SemiBold" TextTrimming="CharacterEllipsis"/><TextBlock x:Name="NowArtist" Text="Atesh studio" Foreground="#A4A4AD" FontSize="11" Margin="0,5,0,0" TextTrimming="CharacterEllipsis"/></StackPanel></Grid>
   <StackPanel Grid.Column="1"><StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,5"><Button x:Name="Shuffle" Content="⇄" ToolTip="Karışık çal" AutomationProperties.Name="Karışık çal" Background="Transparent" BorderThickness="0" FontSize="20" Padding="12,6"/><Button x:Name="Prev" Content="❮❮" ToolTip="Önceki şarkı" Background="Transparent" BorderThickness="0" Padding="12,6"/><Button x:Name="Play" Content="▶" ToolTip="Oynat / duraklat" Background="#F7F7FA" Foreground="#121215" BorderThickness="0" Width="52" Height="42" Padding="0"/><Button x:Name="Next" Content="❯❯" ToolTip="Sonraki şarkı" Background="Transparent" BorderThickness="0" Padding="12,6"/><Button x:Name="Repeat" Content="↻" ToolTip="Şarkıyı tekrarla" AutomationProperties.Name="Şarkıyı tekrarla" Background="Transparent" BorderThickness="0" FontSize="20" Padding="12,6"/></StackPanel><DockPanel><TextBlock x:Name="Elapsed" Text="0:00" Foreground="#A4A4AD" Width="38" FontSize="10" VerticalAlignment="Center"/><TextBlock x:Name="Duration" Text="0:00" Foreground="#A4A4AD" DockPanel.Dock="Right" Width="38" TextAlignment="Right" FontSize="10" VerticalAlignment="Center"/><Slider x:Name="Seek" Minimum="0" Maximum="1" Value="0" VerticalAlignment="Center" AutomationProperties.Name="Şarkı konumu"/></DockPanel></StackPanel>
   <StackPanel Grid.Column="2" Margin="18,0,0,0" VerticalAlignment="Center"><Button x:Name="MiniToggle" Content="↗  Mini oynatıcı" FontSize="9" Padding="6,4" Margin="0,0,0,3"/><TextBlock Text="SES DÜZEYİ" Foreground="#A4A4AD" FontSize="9" Margin="0,0,0,5"/><Slider x:Name="Volume" Minimum="0" Maximum="1" Value="0.7" AutomationProperties.Name="Ses düzeyi"/></StackPanel>
  </Grid></Border>
  <Border x:Name="QueuePanel" Grid.Row="0" Visibility="Collapsed" Width="340" Height="430" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,28,18" Background="#18181D" BorderBrush="#484852" BorderThickness="1" CornerRadius="14" Padding="16">
   <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <DockPanel Margin="0,0,0,12"><Button x:Name="QueueClose" Content="✕" DockPanel.Dock="Right" Padding="8,4" Margin="0"/><StackPanel><TextBlock Text="Çalma kuyruğu" FontSize="19" FontWeight="SemiBold"/><TextBlock x:Name="QueueCount" Foreground="#B1B1BA" FontSize="11" Margin="0,5,0,0"/></StackPanel></DockPanel>
    <Grid Grid.Row="1"><ListBox x:Name="QueueTracks" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><StackPanel><TextBlock Text="{Binding Label}" FontSize="12" TextTrimming="CharacterEllipsis"/><TextBlock Text="{Binding Artist}" FontSize="10" Foreground="#B1B1BA" Margin="0,4,0,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></ListBox.ItemTemplate></ListBox><TextBlock x:Name="QueueEmpty" Text="Sırada henüz şarkı yok.&#10;Kütüphanenden kuyruğa şarkı ekle." TextAlignment="Center" VerticalAlignment="Center" Foreground="#B1B1BA"/></Grid>
    <WrapPanel Grid.Row="2" Margin="0,12,0,0"><Button x:Name="QueuePlay" Content="▶" ToolTip="Seçileni çal"/><Button x:Name="QueueUp" Content="↑" ToolTip="Yukarı taşı"/><Button x:Name="QueueDown" Content="↓" ToolTip="Aşağı taşı"/><Button x:Name="QueueRemove" Content="Çıkar"/></WrapPanel>
    <TextBlock Grid.Row="3" Text="Şarkıyı seç, oklarla sırasını değiştir." Foreground="#B1B1BA" FontSize="10" Margin="0,10,0,0"/>
   </Grid>
  </Border>
  <Grid x:Name="SettingsOverlay" Grid.RowSpan="2" Visibility="Collapsed" Background="#D0050508">
   <Border Width="620" MaxHeight="620" Margin="20" Padding="26" HorizontalAlignment="Center" VerticalAlignment="Center" Background="#18181D" BorderBrush="#484852" BorderThickness="1" CornerRadius="18">
    <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
     <DockPanel><Button x:Name="SettingsClose" Content="✕" DockPanel.Dock="Right" Padding="8,4" Margin="0"/><StackPanel><TextBlock Text="Ayarlar" FontSize="24" FontWeight="SemiBold"/><TextBlock Text="Atesh Studio · V5.6" Foreground="#8E8E98" FontSize="11" Margin="0,4,0,0"/></StackPanel></DockPanel>
     <Border Grid.Row="1" Background="#121216" BorderBrush="#292930" BorderThickness="1" CornerRadius="12" Padding="14" Margin="0,18,0,12"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Tema" FontWeight="SemiBold"/><TextBlock Text="Atesh Dark · siyah, antrasit ve kırmızı" Foreground="#8E8E98" FontSize="10" Margin="0,4,0,0"/></StackPanel><Border Grid.Column="1" Background="#29161C" CornerRadius="8" Padding="10,5"><TextBlock Text="ATESH DARK" Foreground="#F43F53" FontSize="9" FontWeight="Bold"/></Border></Grid></Border>
     <Grid Grid.Row="2" Margin="0,0,0,10"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="İzlenen müzik klasörleri" FontWeight="SemiBold"/><TextBlock Text="Uygulama açılırken bu klasörlerde yeni veya taşınmış müzikler aranır." Foreground="#8E8E98" FontSize="10" Margin="0,4,0,0"/></StackPanel><CheckBox x:Name="AutoScan" Grid.Column="1" Content="Açılışta tara" VerticalAlignment="Center" Foreground="#E8E8EC" Margin="12,0,0,0"/></Grid>
     <Border Grid.Row="3" Background="#101013" BorderBrush="#292930" BorderThickness="1" CornerRadius="10" Padding="10"><Grid><Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions><ListBox x:Name="WatchFolders" Background="Transparent" BorderThickness="0" MinHeight="120" MaxHeight="230"/><WrapPanel Grid.Row="1" Margin="0,10,0,0"><Button x:Name="WatchAdd" Content="+ Klasör ekle"/><Button x:Name="WatchRemove" Content="Kaldır"/><Button x:Name="WatchScanNow" Content="Şimdi tara"/></WrapPanel></Grid></Border>
     <StackPanel Grid.Row="4" Margin="0,16,0,0"><WrapPanel><Button x:Name="BackupLibrary" Content="Yedekle"/><Button x:Name="RestoreLibrary" Content="Geri yükle"/><Button x:Name="CheckUpdate" Content="Güncellemeleri denetle"/></WrapPanel><TextBlock Text="V5.6.0 · Kişisel verilerin güncellemelerde korunur." Foreground="#7E7E88" FontSize="9" Margin="0,8,0,0"/></StackPanel>
    </Grid>
   </Border>
  </Grid>
  <Grid x:Name="CollectionOverlay" Grid.RowSpan="2" Visibility="Collapsed" Background="#D0050508">
   <Border Width="550" MaxHeight="640" Margin="20" Padding="26" HorizontalAlignment="Center" VerticalAlignment="Center" Background="#18181D" BorderBrush="#484852" BorderThickness="1" CornerRadius="18"><Border.Effect><DropShadowEffect BlurRadius="40" ShadowDepth="14" Opacity="0.65"/></Border.Effect>
    <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*" MinHeight="100"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
     <DockPanel><Button x:Name="CollectionClose" Content="✕" DockPanel.Dock="Right" Padding="8,4" Margin="0"/><TextBlock x:Name="CollectionTitle" Text="Yeni çalma listesi" FontSize="24" FontWeight="SemiBold"/></DockPanel>
     <StackPanel Grid.Row="1" Margin="0,16,0,12"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="94"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Width="80" Height="80" Background="#341A23" CornerRadius="9" HorizontalAlignment="Left"><Grid><TextBlock Text="♫" Foreground="#F43F53" FontSize="30" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image x:Name="CollectionCoverPreview" Stretch="UniformToFill"/></Grid></Border><StackPanel Grid.Column="1"><TextBlock Text="Çalma listesi adı" Foreground="#C4C4CC" Margin="0,0,0,6"/><TextBox x:Name="CollectionName" Height="42" MaxLength="80" AutomationProperties.Name="Çalma listesi adı"/><WrapPanel Margin="0,8,0,0"><Button x:Name="ChooseCollectionCover" Content="Kapak seç" Padding="10,5"/><Button x:Name="ClearCollectionCover" Content="Kapağı kaldır" Padding="10,5"/></WrapPanel></StackPanel></Grid><TextBlock x:Name="CollectionError" Foreground="#FF9CA7" TextWrapping="Wrap" Margin="0,7,0,0"/></StackPanel>
     <Grid Grid.Row="2" Margin="0,0,0,10"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="Şarkıları seç ve sırala" FontWeight="SemiBold" VerticalAlignment="Center"/><StackPanel Grid.Column="1" Orientation="Horizontal"><Button x:Name="EditorUp" Visibility="Collapsed" Content="↑" ToolTip="Seçili şarkıları yukarı taşı" Padding="9,5"/><Button x:Name="EditorDown" Visibility="Collapsed" Content="↓" ToolTip="Seçili şarkıları aşağı taşı" Padding="9,5"/><Button x:Name="SelectAllTracks" Content="Tümünü seç" Padding="10,5" Margin="0"/></StackPanel></Grid>
     <Grid Grid.Row="3"><ListBox x:Name="CollectionTracks" SelectionMode="Multiple" Background="#101013" BorderThickness="0" MinHeight="160" MaxHeight="280" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><DockPanel><StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center" Margin="8,0,0,0"><Button Content="↑" Tag="{Binding Id}" CommandParameter="-1" ToolTip="Bu şarkıyı yukarı taşı" Padding="8,4" Margin="0,0,4,0"/><Button Content="↓" Tag="{Binding Id}" CommandParameter="1" ToolTip="Bu şarkıyı aşağı taşı" Padding="8,4" Margin="0"/></StackPanel><CheckBox IsChecked="{Binding IsSelected, RelativeSource={RelativeSource AncestorType=ListBoxItem}, Mode=TwoWay}" VerticalAlignment="Center" Margin="0,0,12,0" Focusable="False" IsHitTestVisible="False"/><StackPanel><TextBlock Text="{Binding Title}" TextTrimming="CharacterEllipsis"/><TextBlock Text="{Binding Artist}" Foreground="#A4A4AD" FontSize="11" Margin="0,4,0,0"/></StackPanel></DockPanel></DataTemplate></ListBox.ItemTemplate></ListBox><TextBlock x:Name="CollectionEmpty" Text="Henüz müzik eklenmemiş.&#10;Boş liste oluşturup daha sonra şarkı ekleyebilirsin." TextAlignment="Center" Foreground="#B1B1BA" VerticalAlignment="Center" IsHitTestVisible="False"/></Grid>
     <TextBlock x:Name="CollectionCount" Grid.Row="4" Foreground="#B1B1BA" Margin="0,12,0,16"/>
     <DockPanel Grid.Row="5"><StackPanel Orientation="Horizontal" DockPanel.Dock="Left"><Button x:Name="DeleteCollection" Content="Sil" Foreground="#FF9CA7"/><Button x:Name="DuplicateCollection" Content="Çoğalt"/></StackPanel><StackPanel Orientation="Horizontal" HorizontalAlignment="Right"><Button x:Name="CollectionCancel" Content="Vazgeç"/><Button x:Name="CollectionSave" Content="Oluştur" Background="#F43F53" Foreground="#FFFFFF" FontWeight="SemiBold" Margin="0" Padding="24,11"/></StackPanel></DockPanel>
    </Grid>
   </Border>
  </Grid>
 </Grid>
</Window>

'@
$script:window = [Windows.Markup.XamlReader]::Load([System.Xml.XmlNodeReader]::new($xaml))
if(Test-Path -LiteralPath (Join-Path $homeDir 'Atesh-Studio.ico')){$window.Icon=[Windows.Media.Imaging.BitmapFrame]::Create([Uri]::new((Join-Path $homeDir 'Atesh-Studio.ico')))}
$ui = @{}
foreach($name in 'Home,Social,SocialPanel,SocialCount,SocialRefresh,SocialUsername,SocialPrivacy,SocialSave,SocialUsers,SocialEmpty,SocialLiveTab,SocialProfileTab,SocialFollowingTab,SocialLiveView,SocialProfileView,SocialFollowingView,ProfileUsername,ProfileBio,ProfileAvatarUrl,ProfileAvatarChoose,ProfileAvatarClear,ProfileLocalAvatarHint,ProfilePrivacy,ProfileSave,ProfilePreviewInitial,ProfilePreviewAvatar,ProfilePreviewUsername,ProfilePrivacyBadge,ProfilePreviewBio,ProfilePreviewTrack,ProfileFollowingCount,ProfileStatusText,FollowUsername,FollowAdd,FollowStatus,FollowingUsers,FollowingEmpty,QuickAll,QuickHistory,QuickFav,SeeHistory,SmartWeek,SmartForgotten,SmartNewest,SmartFavMix,Artists,History,HistToday,HistYesterday,HistWeek,Hist30,HistoryFilterBar,EntityBack,EntityBrowser,EntityBrowserTitle,EntityBrowserHint,EntityList,ScanFolder,Settings,SettingsOverlay,SettingsClose,AutoScan,WatchFolders,WatchAdd,WatchRemove,WatchScanNow,BackupLibrary,RestoreLibrary,CheckUpdate,HomeDashboard,LibraryPanel,ActionBar,ViewHint,ViewTypeBadge,ViewTypeText,RecentShelf,ForYouShelf,TopShelf,NewestShelf,SideNowFallback,SideNowInitial,SideNowCover,SideNowTitle,SideNowArtist,SideNowMeta,SideFavorite,SideAddList,SideQueueOpen,SideQueue,SideQueueCount,CollectionHeaderCover,CollectionCoverPreview,ChooseCollectionCover,ClearCollectionCover,EditorUp,EditorDown,DeleteCollection,DuplicateCollection,TrackCover,MiniToggle,RecordScene,MotionToggle,EditList,CollectionOverlay,CollectionTitle,CollectionName,CollectionError,CollectionTracks,CollectionEmpty,CollectionCount,CollectionClose,CollectionCancel,CollectionSave,SelectAllTracks,QueueToggle,QueuePanel,QueueClose,QueueCount,QueueTracks,QueueEmpty,QueuePlay,QueueUp,QueueDown,QueueRemove,Enqueue,NowFallback,NowInitial,NowCover,All,Fav,ListName,NewList,Lists,Import,Heading,Count,LibraryStat,ListStat,Search,Tracks,Empty,PlaySelected,Favorite,AddList,RemoveList,Status,NowTitle,NowArtist,Shuffle,Prev,Play,Next,Repeat,Elapsed,Duration,Seek,Volume'.Split(',')) { $ui[$name] = $window.FindName($name) }
$script:player = [Windows.Media.MediaPlayer]::new()
$player.Volume = 0.7
$script:scene=[DostScene]::new($ui.RecordScene)
$script:historyRange='30'
$window.Add_SourceInitialized({[DostScene]::DarkTitle(([Windows.Interop.WindowInteropHelper]::new($window)).Handle)})
$script:motionEnabled=$true
$script:editingCollection=$null
$ui.RecordScene.Add_MouseMove({param($sender,$e) if($script:motionEnabled){$point=$e.GetPosition($ui.RecordScene);$script:scene.Tilt.Angle=-32+22*($point.X/[Math]::Max(1,$ui.RecordScene.ActualWidth))}})
$ui.RecordScene.Add_MouseLeave({$script:scene.Tilt.Angle=-22})
$ui.MotionToggle.Add_Click({$script:motionEnabled=-not $script:motionEnabled;$ui.MotionToggle.Content=if($script:motionEnabled){'3D • Açık'}else{'3D • Sabit'};$script:scene.Tilt.Angle=-22})
function Save-Library {
 $script:lastSaveSucceeded=$false
 try {
  $json = @{Tracks=@($script:library.ToArray()); Lists=@($script:lists.ToArray()); Queue=@($script:queue); CollectionMeta=$script:collectionMeta; History=@($script:history)} | ConvertTo-Json -Depth 8
  [IO.File]::WriteAllText("$script:dataFile.tmp",$json,[Text.UTF8Encoding]::new($true))
  Move-Item -LiteralPath "$script:dataFile.tmp" -Destination $script:dataFile -Force
  $script:lastSaveSucceeded=$true
 } catch { $ui.Status.Text = 'Kütüphane kaydedilemedi: ' + $_.Exception.Message }
}
function Open-CollectionEditor([string]$existing='') {
 $script:editingCollection=if($existing -and $lists.Contains($existing)){$existing}else{$null}
 $ui.CollectionTitle.Text=if($script:editingCollection){'Çalma listesini düzenle'}else{'Yeni çalma listesi'}
 $ui.CollectionSave.Content=if($script:editingCollection){'Kaydet'}else{'Oluştur'}
 $ui.CollectionName.Text=if($script:editingCollection){$script:editingCollection}else{''}
 $ui.CollectionError.Text=''
 $meta=if($script:editingCollection){$script:collectionMeta[$script:editingCollection]}else{$null}
 $script:draftCover=if($meta){[string]$meta.Cover}else{''}
 $ui.CollectionCoverPreview.Source=Read-CoverAsset $script:draftCover
 $ui.DeleteCollection.Visibility=if($script:editingCollection){'Visible'}else{'Collapsed'}
 $ui.DuplicateCollection.Visibility=$ui.DeleteCollection.Visibility
 $order=@(if($meta){$meta.Order})
 $allTracks=@($library.ToArray())
 $ui.CollectionTracks.ItemsSource=@($allTracks | Sort-Object @{Expression={$index=[Array]::IndexOf($order,$_.Id);if($index -lt 0){[int]::MaxValue}else{$index}}},@{Expression={[Array]::IndexOf($allTracks,$_)} })
 $ui.CollectionTracks.UnselectAll()
 $selected=Get-SelectedTrack
 foreach($track in $library){if(($script:editingCollection -and @($track.Lists) -contains $script:editingCollection) -or (-not $script:editingCollection -and $selected -and $track.Id -eq $selected.Id)){[void]$ui.CollectionTracks.SelectedItems.Add($track)}}
 $ui.CollectionEmpty.Visibility=if($library.Count -eq 0){'Visible'}else{'Collapsed'}
 $ui.CollectionCount.Text="$($ui.CollectionTracks.SelectedItems.Count) şarkı seçildi"
 $ui.QueuePanel.Visibility='Collapsed';$ui.CollectionOverlay.Visibility='Visible'
 [void]$ui.CollectionName.Focus()
}
function Save-CollectionEditor {
 $name=$ui.CollectionName.Text.Trim()
 if([string]::IsNullOrWhiteSpace($name)){$ui.CollectionError.Text='Listeye bir isim ver; örneğin Gece Yolculuğu.';[void]$ui.CollectionName.Focus();return}
 if($name.Length -gt 80 -or $name -in @('all','fav')){$ui.CollectionError.Text='80 karakteri geçmeyen farklı bir ad seç.';return}
 if(@($lists | Where-Object {$_ -ine $script:editingCollection}) -contains $name){$ui.CollectionError.Text='Bu isimde bir listen var. Başka bir ad yaz.';return}
 $oldNames=@($lists.ToArray());$oldMembership=@{}
 foreach($track in $library){$oldMembership[$track.Id]=@($track.Lists)}
 $selected=@($ui.CollectionTracks.SelectedItems | ForEach-Object {$_.Id})
 $selectedIds=@($ui.CollectionTracks.ItemsSource | Where-Object {$selected -contains $_.Id} | ForEach-Object {$_.Id})
 $oldMeta=$script:collectionMeta.Clone()
 if($script:editingCollection){$script:collectionMeta.Remove($script:editingCollection)}
 $script:collectionMeta[$name]=@{Cover=$script:draftCover;Order=$selectedIds}
 if($script:editingCollection){$lists[$lists.IndexOf($script:editingCollection)]=$name}else{[void]$lists.Add($name)}
 foreach($track in $library){
  if($script:editingCollection){$track.Lists=@($track.Lists | Where-Object {$_ -ine $script:editingCollection})}
  if($selectedIds -contains $track.Id -and @($track.Lists) -notcontains $name){$track.Lists=@($track.Lists)+@($name)}
 }
 Save-Library
 if(-not $script:lastSaveSucceeded){
  $script:collectionMeta=$oldMeta
  $lists.Clear();foreach($oldName in $oldNames){[void]$lists.Add($oldName)}
  foreach($track in $library){$track.Lists=$oldMembership[$track.Id]}
  $ui.CollectionError.Text='Liste kaydedilemedi. Uygulama klasörünün yazılabilir olduğundan emin ol.';return
 }
 $ui.CollectionOverlay.Visibility='Collapsed'
 $ui.Lists.ItemsSource=$lists.ToArray();$ui.Search.Clear();$ui.Lists.SelectedItem=$name
 $script:view=$name;$ui.Heading.Text=$name;Refresh-Tracks
 $ui.Status.Text="Liste hazır: $name · $($selectedIds.Count) şarkı. Şarkı eklemek için Listeyi düzenle'yi kullan."
}
function New-FallbackBrush([string]$seed) {
 $palettes=@(
  @('#4B1724','#C52B48'),@('#18213B','#4C63C7'),@('#17362E','#2E8B72'),
  @('#3A1C3D','#A13F91'),@('#3D2917','#B7792D'),@('#1B303B','#3C8AA6'),
  @('#2D1C35','#7E4BA8'),@('#321C22','#9C4659')
 )
 if([string]::IsNullOrWhiteSpace($seed)){$seed='Atesh'}
 $hash=0;foreach($ch in $seed.ToCharArray()){$hash=(($hash*31)+[int]$ch) -band 0x7fffffff}
 $pair=$palettes[$hash % $palettes.Count]
 return [Windows.Media.LinearGradientBrush]::new([Windows.Media.ColorConverter]::ConvertFromString($pair[0]),[Windows.Media.ColorConverter]::ConvertFromString($pair[1]),45)
}
function Get-Initial([object]$track) {
 $text=if($track.Artist){[string]$track.Artist}elseif($track.Title){[string]$track.Title}else{'A'}
 $text=$text.Trim(); if($text.Length -eq 0){return 'A'}
 return $text.Substring(0,1).ToUpperInvariant()
}
function Convert-ToShelfRows($items) {
 return @($items | Where-Object {$null -ne $_} | ForEach-Object {
  $plays=if($_.PlayCount){[int]$_.PlayCount}else{0}
  $initial=Get-Initial $_
  [pscustomobject]@{Id=$_.Id;Title=$_.Title;Artist=$_.Artist;Subtitle=$(if($plays -gt 0){"$($_.Artist) · $plays dinleme"}else{$_.Artist});Cover=(Get-Cover $_.Path);Initial=$initial;CoverBrush=(New-FallbackBrush ($_.Artist+'|'+$_.Title))}
 })
}
function Get-UniqueShelfTracks($items,[int]$limit=7) {
 $seen=@{};$result=[System.Collections.ArrayList]::new()
 foreach($t in @($items)){
  if($null -eq $t){continue}
  $key=(($t.Artist+'|'+$t.Title).ToLowerInvariant())
  if(-not $seen.ContainsKey($key)){$seen[$key]=$true;[void]$result.Add($t)}
  if($result.Count -ge $limit){break}
 }
 return @($result)
}
function Refresh-HomeShelves {
 $source=@($script:library)
 $recent=Get-UniqueShelfTracks @($source | Where-Object {$_.LastPlayed} | Sort-Object {[datetime]$_.LastPlayed} -Descending) 7
 if($recent.Count -eq 0){$recent=Get-UniqueShelfTracks @($source | Sort-Object @{Expression={if($_.DateAdded){[datetime]$_.DateAdded}else{[datetime]::MinValue}};Descending=$true}) 7}
 $weekKey=(Get-Date).ToString('yyyy-ww')
 $top=Get-UniqueShelfTracks @($source | Where-Object {$_.WeekKey -eq $weekKey -and [int]$_.WeekPlayCount -gt 0} | Sort-Object @{Expression={[int]$_.WeekPlayCount};Descending=$true},@{Expression={$_.Title}}) 7
 if($top.Count -eq 0){$top=Get-UniqueShelfTracks @($source | Sort-Object @{Expression={[int]$_.PlayCount};Descending=$true},@{Expression={$_.Title}}) 7}
 $fav=@($source | Where-Object {$_.Favorite} | Select-Object -First 4)
 $newest=Get-UniqueShelfTracks @($source | Sort-Object @{Expression={if($_.DateAdded){[datetime]$_.DateAdded}else{[datetime]::MinValue}};Descending=$true}) 7
 $seen=@{};$forYou=[System.Collections.ArrayList]::new()
 foreach($t in @($fav+$newest+$top)){if($t -and -not $seen.ContainsKey($t.Id)){$seen[$t.Id]=$true;[void]$forYou.Add($t)};if($forYou.Count -ge 7){break}}
 $ui.RecentShelf.ItemsSource=Convert-ToShelfRows $recent
 $ui.ForYouShelf.ItemsSource=Convert-ToShelfRows @($forYou)
 $ui.TopShelf.ItemsSource=Convert-ToShelfRows $top
 $ui.NewestShelf.ItemsSource=Convert-ToShelfRows $newest
}
function Get-ShelfTrack($sender){
 if($sender.SelectedItem){return ($library | Where-Object Id -eq $sender.SelectedItem.Id | Select-Object -First 1)}
 return $null
}
function Test-SearchMatch($track,[string]$query) {
 if([string]::IsNullOrWhiteSpace($query)){return $true}
 $q=$query.Trim()
 $parts=@($q -split '\s+' | Where-Object {$_})
 foreach($part in $parts){
  if($part -match '^(artist|sanatci|sanatçı):(.+)$'){if(([string]$track.Artist).IndexOf($Matches[2],[StringComparison]::CurrentCultureIgnoreCase) -lt 0){return $false};continue}
  if($part -match '^(album|albüm):(.+)$'){if(([string]$track.Album).IndexOf($Matches[2],[StringComparison]::CurrentCultureIgnoreCase) -lt 0){return $false};continue}
  if($part -match '^fav:(1|true|evet)$'){if(-not $track.Favorite){return $false};continue}
  if($part -match '^type:(.+)$'){if(([IO.Path]::GetExtension($track.Path).TrimStart('.')).IndexOf($Matches[1],[StringComparison]::CurrentCultureIgnoreCase) -lt 0){return $false};continue}
  if((($track.Title+' '+$track.Artist+' '+$track.Album).IndexOf($part,[StringComparison]::CurrentCultureIgnoreCase)) -lt 0){return $false}
 }
 return $true
}
function Test-HistoryRange($track) {
 if(-not $track.LastPlayed){return $false}
 try{$d=([datetime]$track.LastPlayed).ToLocalTime()}catch{return $false}
 $now=[datetime]::Now
 switch($script:historyRange){
  'today' {return $d.Date -eq $now.Date}
  'yesterday' {return $d.Date -eq $now.Date.AddDays(-1)}
  'week' {$offset=((([int]$now.DayOfWeek+6)%7));$start=$now.Date.AddDays(-$offset);return ($d -ge $start)}
  default {return ($d -ge $now.AddDays(-30))}
 }
}
function Test-SystemView([string]$view){
 return ($view -in @('home','all','artists','history','fav','social','smartweek','smartforgotten','smartnewest','smartfavmix') -or $view.StartsWith('artist::'))
}
function Refresh-EntityBrowser {
 if($script:view -ne 'artists'){$ui.EntityBrowser.Visibility='Collapsed';return}
 $groups=@{}
 foreach($t in @($script:library)){
  $name=[string]$t.Artist
  if([string]::IsNullOrWhiteSpace($name)){$name='Bilinmeyen sanatçı'}
  if(-not $groups.ContainsKey($name)){$groups[$name]=[System.Collections.ArrayList]::new()}
  [void]$groups[$name].Add($t)
 }
 $rows=@(foreach($name in ($groups.Keys | Sort-Object)){
  $items=@($groups[$name]);$plays=($items|Measure-Object PlayCount -Sum).Sum;if($null -eq $plays){$plays=0}
  $initial=if($name){$name.Trim().Substring(0,1).ToUpperInvariant()}else{'A'}
  [pscustomobject]@{Name=$name;Kind='artist';Initial=$initial;Brush=(New-FallbackBrush $name);Meta="$($items.Count) şarkı";Plays="$plays dinleme"}
 })
 $ui.EntityBrowserTitle.Text='Sanatçılar'
 $ui.EntityList.ItemsSource=$rows
 $ui.EntityBrowser.Visibility='Visible'
}
$script:socialSubView='live'
function Show-SocialSubview([string]$mode) {
 try{$ui.MainViewHeader.Visibility='Collapsed'}catch{}
 $script:socialSubView=$mode
 $ui.SocialLiveView.Visibility=if($mode -eq 'live'){'Visible'}else{'Collapsed'}
 $ui.SocialProfileView.Visibility=if($mode -eq 'profile'){'Visible'}else{'Collapsed'}
 $ui.SocialFollowingView.Visibility=if($mode -eq 'following'){'Visible'}else{'Collapsed'}
 $ui.SocialLiveTab.Background=if($mode -eq 'live'){'#3A171F'}else{'Transparent'}
 $ui.SocialProfileTab.Background=if($mode -eq 'profile'){'#3A171F'}else{'Transparent'}
 $ui.SocialFollowingTab.Background=if($mode -eq 'following'){'#3A171F'}else{'Transparent'}
 $ui.SocialLiveTab.BorderBrush=if($mode -eq 'live'){'#F43F53'}else{'#303038'}
 $ui.SocialProfileTab.BorderBrush=if($mode -eq 'profile'){'#F43F53'}else{'#303038'}
 $ui.SocialFollowingTab.BorderBrush=if($mode -eq 'following'){'#F43F53'}else{'#303038'}
 $ui.SocialLiveTab.Foreground=if($mode -eq 'live'){'#FFFFFF'}else{'#A0A0AA'}
 $ui.SocialProfileTab.Foreground=if($mode -eq 'profile'){'#FFFFFF'}else{'#A0A0AA'}
 $ui.SocialFollowingTab.Foreground=if($mode -eq 'following'){'#FFFFFF'}else{'#A0A0AA'}
 if($mode -eq 'profile'){Refresh-SocialProfileUI}
 if($mode -eq 'following'){Refresh-SocialFollowingUI}
}
function Set-ProfilePreviewAvatarSource {
 try {
  $sourcePath=''
  if([string]$script:socialState.LocalAvatarPath -and (Test-Path -LiteralPath ([string]$script:socialState.LocalAvatarPath))){$sourcePath=[string]$script:socialState.LocalAvatarPath}
  elseif([string]$script:socialState.AvatarUrl){$sourcePath=[string]$script:socialState.AvatarUrl}
  if([string]::IsNullOrWhiteSpace($sourcePath)){$ui.ProfilePreviewAvatar.Source=$null;return}
  $bmp=[Windows.Media.Imaging.BitmapImage]::new();$bmp.BeginInit();$bmp.CacheOption=[Windows.Media.Imaging.BitmapCacheOption]::OnLoad;$bmp.UriSource=[Uri]$sourcePath;$bmp.EndInit();$bmp.Freeze();$ui.ProfilePreviewAvatar.Source=$bmp
 } catch {$ui.ProfilePreviewAvatar.Source=$null}
}
function Refresh-SocialProfileUI {
 try {
  $ui.ProfileUsername.Text=$script:socialState.Username
  $ui.ProfileBio.Text=[string]$script:socialState.Bio
  $ui.ProfileAvatarUrl.Text=[string]$script:socialState.AvatarUrl
  $ui.ProfilePrivacy.SelectedIndex=if($script:socialState.Privacy -eq 'hidden'){1}else{0}
  $name=[string]$script:socialState.Username
  $ui.ProfilePreviewUsername.Text=if($name){$name}else{'Atesh'}
  $ui.ProfilePreviewInitial.Text=if($name){$name.Substring(0,1).ToUpperInvariant()}else{'A'}
  $ui.ProfilePreviewBio.Text=if([string]$script:socialState.Bio){[string]$script:socialState.Bio}else{'Profiline kısa bir durum ekle.'}
  $ui.ProfilePrivacyBadge.Text=if($script:socialState.Privacy -eq 'hidden'){'Gizli mod'}else{'Herkese açık'}
  Set-ProfilePreviewAvatarSource
  $isPlaying=[bool]($script:current -and $script:playing)
  $ui.ProfilePreviewTrack.Text=if($isPlaying){'Şimdi dinliyor · '+[string]$script:current.Title+' · '+[string]$script:current.Artist}else{'Şu an müzik çalmıyor'}
  $ui.ProfileStatusText.Text=if($script:socialState.Privacy -eq 'hidden'){'Gizli'}elseif($isPlaying){'Dinliyor'}else{'Çevrimiçi'}
  if($null -eq $script:lastFollowingRows){$script:lastFollowingRows=@(Get-AteshFollowingUsers)}
  $ui.ProfileFollowingCount.Text=[string]@($script:lastFollowingRows).Count
  if([string]$script:socialState.LocalAvatarPath -and (Test-Path -LiteralPath ([string]$script:socialState.LocalAvatarPath))){$ui.ProfileLocalAvatarHint.Text='Yerel fotoğraf aktif · Profilim ve kendi Canlı kartında kullanılıyor.'}else{$ui.ProfileLocalAvatarHint.Text='Bilgisayardan seçilen fotoğraf bu cihazda Profilim ve kendi Canlı kartında görünür.'}
 } catch {}
}
function Refresh-SocialFollowingUI {
 try {
  $sourceRows=@(Get-AteshFollowingUsers)
  $script:lastFollowingRows=$sourceRows
  $rows=@(foreach($u in $sourceRows){$name=[string]$u.username;$initial=if($name){$name.Substring(0,1).ToUpperInvariant()}else{'A'};[pscustomobject]@{UserId=[string]$u.user_id;Username=$name;Bio=[string]$u.bio;AvatarUrl=[string]$u.avatar_url;Initial=$initial}})
  $ui.FollowingUsers.ItemsSource=$rows
  $ui.FollowingEmpty.Visibility=if($rows.Count -eq 0){'Visible'}else{'Collapsed'}
  $ui.ProfileFollowingCount.Text=[string]$rows.Count
 } catch {$ui.FollowStatus.Text='Takip listesi alınamadı.';$ui.ProfileFollowingCount.Text='0'}
}
function Get-AteshLocalLiveRow {
 try {
  $name=[string]$script:socialState.Username
  if([string]::IsNullOrWhiteSpace($name)){$name='Atesh'}
  $initial=if($name){$name.Substring(0,1).ToUpperInvariant()}else{'A'}
  $avatar=[string]$script:socialState.AvatarUrl
  if([string]$script:socialState.LocalAvatarPath -and (Test-Path -LiteralPath ([string]$script:socialState.LocalAvatarPath))){
   try{$avatar=([Uri]([string]$script:socialState.LocalAvatarPath)).AbsoluteUri}catch{$avatar=[string]$script:socialState.LocalAvatarPath}
  }
  $isPlaying=[bool]($script:current -and $script:playing)
  $trackText=if($isPlaying){([string]$script:current.Title)+$(if($script:current.Artist){' · '+[string]$script:current.Artist}else{''})}else{'Çevrimiçi'}
  $activityLabel=if($script:socialState.Privacy -eq 'hidden'){
   if($isPlaying){'ŞİMDİ DİNLİYOR · GİZLİ'}else{'GİZLİ MOD'}
  }elseif($isPlaying){'ŞİMDİ DİNLİYOR'}else{'AKTİF'}
  return [pscustomobject]@{
   UserId=[string]$script:socialState.UserId
   Username=$name
   Bio=[string]$script:socialState.Bio
   AvatarUrl=$avatar
   ActivityLabel=$activityLabel
   TrackText=$trackText
   Initial=$initial
   IsLocal=$true
  }
 } catch {return $null}
}
function Refresh-SocialUI {
 try {
  $ui.SocialUsername.Text=$script:socialState.Username
  $ui.SocialPrivacy.SelectedIndex=if($script:socialState.Privacy -eq 'hidden'){1}else{0}
  if($script:current -and $script:playing){[void](Send-AteshSocialStatus $true ([string]$script:current.Title) ([string]$script:current.Artist))}else{[void](Send-AteshSocialStatus $true '' '')}

  # Supabase güncellemesi arka planda olduğu için gizlilik/profil değişiminden hemen
  # sonra sunucudan eski satır dönebilir. Kendi kartımızı her zaman yerel state'ten
  # üretip sunucu sonucunun üzerine yazarız. Böylece avatar/bio/premium kart tasarımı
  # hiçbir zaman eski/fallback görünüme dönmez ve Yenile'ye ihtiyaç kalmaz.
  $users=@(Get-AteshSocialUsers)
  $rows=[System.Collections.ArrayList]::new()
  $ownAdded=$false
  foreach($u in $users){
   if(([string]$u.user_id -eq [string]$script:socialState.UserId) -and -not [string]::IsNullOrWhiteSpace([string]$script:socialState.UserId)){
    $own=Get-AteshLocalLiveRow
    if($own){[void]$rows.Add($own);$ownAdded=$true}
    continue
   }
   $name=[string]$u.username
   $hasTrack=-not [string]::IsNullOrWhiteSpace([string]$u.track_title)
   $trackText=if($hasTrack){([string]$u.track_title)+$(if($u.artist){' · '+[string]$u.artist}else{''})}else{'Çevrimiçi'}
   $activityLabel=if($hasTrack){'ŞİMDİ DİNLİYOR'}else{'AKTİF'}
   $initial=if($name){$name.Substring(0,1).ToUpperInvariant()}else{'A'}
   [void]$rows.Add([pscustomobject]@{UserId=[string]$u.user_id;Username=$name;Bio=[string]$u.bio;AvatarUrl=[string]$u.avatar_url;ActivityLabel=$activityLabel;TrackText=$trackText;Initial=$initial;IsLocal=$false})
  }
  # Gizli modda Supabase sorgusu doğal olarak kendi satırımızı döndürmez. Yine de
  # kullanıcı kendi kartını yerel önizleme olarak görmeye devam eder; diğer cihazlar
  # bu kartı göremez. Public moda geçişte de sunucu gecikse bile kart anında doğru kalır.
  if(-not $ownAdded){
   $own=Get-AteshLocalLiveRow
   if($own){$rows.Insert(0,$own);$ownAdded=$true}
  }

  $ui.SocialUsers.ItemsSource=@($rows)
  $ui.SocialEmpty.Visibility=if($rows.Count -eq 0){'Visible'}else{'Collapsed'}
  if($script:socialState.Privacy -eq 'hidden'){
   $ui.SocialCount.Text="$(@($users).Count) görünür kullanıcı çevrimiçi · sen gizli moddasın"
   $ui.Count.Text="$(@($users).Count) görünür kullanıcı aktif"
  }else{
   $ui.SocialCount.Text="$($rows.Count) görünür kullanıcı çevrimiçi"
   $ui.Count.Text="$($rows.Count) kullanıcı aktif"
  }
 } catch {$ui.SocialCount.Text='Topluluk şu anda kullanılamıyor';$ui.SocialEmpty.Visibility='Visible'}
}
function Refresh-Tracks {
 try{$ui.MainViewHeader.Visibility=if($script:view -eq 'social'){'Collapsed'}else{'Visible'}}catch{}
 $selectedId = if($ui.Tracks.SelectedItem) { $ui.Tracks.SelectedItem.Id } else { '' }
 $query=$ui.Search.Text
 $source=@($script:library)
 switch($script:view){
  {$_ -like 'artist::*'} {$name=$script:view.Substring(8);$source=@($source | Where-Object {[string]$_.Artist -eq $name})}
  'home' {
   $recent=@($source | Where-Object {$_.LastPlayed} | Sort-Object {[datetime]$_.LastPlayed} -Descending | Select-Object -First 8)
   $top=@($source | Sort-Object @{Expression={[int]$_.PlayCount};Descending=$true},@{Expression={$_.Title}} | Where-Object {[int]$_.PlayCount -gt 0} | Select-Object -First 8)
   $newest=@($source | Sort-Object @{Expression={if($_.DateAdded){[datetime]$_.DateAdded}else{[datetime]::MinValue}};Descending=$true} | Select-Object -First 8)
   $fav=@($source | Where-Object {$_.Favorite} | Select-Object -First 8)
   $ids=@{};$ordered=[System.Collections.ArrayList]::new()
   foreach($t in @($recent+$top+$fav+$newest)){if($t -and -not $ids.ContainsKey($t.Id)){$ids[$t.Id]=$true;[void]$ordered.Add($t)}}
   $source=@($ordered)
  }
  'artists' {$source=@($source | Sort-Object Artist,Title)}
  'history' {$source=@($source | Where-Object {Test-HistoryRange $_} | Sort-Object {[datetime]$_.LastPlayed} -Descending)}
  'smartweek' {$wk=(Get-Date).ToString('yyyy-ww');$source=@($source | Where-Object {$_.WeekKey -eq $wk -and [int]$_.WeekPlayCount -gt 0} | Sort-Object @{Expression={[int]$_.WeekPlayCount};Descending=$true},Title)}
  'smartforgotten' {$cut=[datetime]::Now.AddDays(-30);$source=@($source | Where-Object {-not $_.LastPlayed -or ([datetime]$_.LastPlayed).ToLocalTime() -lt $cut} | Sort-Object @{Expression={if($_.LastPlayed){[datetime]$_.LastPlayed}else{[datetime]::MinValue}}})}
  'smartnewest' {$source=@($source | Sort-Object @{Expression={if($_.DateAdded){[datetime]$_.DateAdded}else{[datetime]::MinValue}};Descending=$true} | Select-Object -First 50)}
  'smartfavmix' {$favs=@($source | Where-Object {$_.Favorite});if($favs.Count -gt 0){$source=@($favs | Get-Random -Count ([Math]::Min(30,$favs.Count)))}else{$source=@()}}
  'fav' {$source=@($source | Where-Object {$_.Favorite})}
  'all' { }
  default {$source=@($source | Where-Object {@($_.Lists) -contains $script:view})}
 }
 $rows = @($source | Where-Object {
  Test-SearchMatch $_ $query
 } | ForEach-Object {
   $plays=if($_.PlayCount){[int]$_.PlayCount}else{0}
   $extra=if($script:view -eq 'artists'){" · $($_.Artist)"}elseif($script:view -eq 'albums'){" · " + $(if($_.Album){$_.Album}else{'Albümü yok'})}else{''}
   [pscustomobject]@{Id=$_.Id; Title=$_.Title; Artist=$_.Artist; Subtitle=((@($_.Artist,$_.Album) | Where-Object {$_}) -join ' · ') + $(if($plays -gt 0){" · $plays dinleme"}else{''}); Cover=(Get-Cover $_.Path); Mark=$(if($_.Favorite){'♥'}else{''})}
 })
 if($script:collectionMeta.ContainsKey($script:view)){
  $order=@($script:collectionMeta[$script:view].Order);$baseRows=$rows
  $rows=@($rows | Sort-Object @{Expression={$index=[Array]::IndexOf($order,$_.Id);if($index -lt 0){[int]::MaxValue}else{$index}}},@{Expression={[Array]::IndexOf($baseRows,$_)} })
 }
 $ui.Tracks.ItemsSource = $rows
 $artists=@($library | ForEach-Object {$_.Artist} | Where-Object {$_} | Sort-Object -Unique).Count
 $albums=@($library | ForEach-Object {$_.Artist} | Where-Object {$_} | Sort-Object -Unique).Count
 $totalPlays=($library | Measure-Object -Property PlayCount -Sum).Sum;if($null -eq $totalPlays){$totalPlays=0}
 $totalSeconds=($library | Measure-Object -Property TotalSeconds -Sum).Sum;if($null -eq $totalSeconds){$totalSeconds=0};$listenHours=[Math]::Round(([double]$totalSeconds/3600),1)
 $ui.Count.Text = if($script:view.StartsWith('artist::')){$p=($source|Measure-Object PlayCount -Sum).Sum;if($null -eq $p){$p=0};"$($rows.Count) şarkı · $p dinleme"}else{switch($script:view){'artists'{"$artists sanatçı"};'history'{"$($rows.Count) kayıt"};'smartweek'{"$($rows.Count) şarkı · bu hafta"};'smartforgotten'{"$($rows.Count) şarkı · yeniden keşfet"};'smartnewest'{"$($rows.Count) yeni şarkı"};'smartfavmix'{"$($rows.Count) favori"};'home'{"$($rows.Count) öneri · $totalPlays oynatma · $listenHours saat dinleme"};default{"$($rows.Count) şarkı"}}}
 $ui.LibraryStat.Text = "$($library.Count) şarkı"
 $ui.ListStat.Text = "$artists sanatçı"
 foreach($n in @('Home','All','Artists','History','Fav','Social')){$ui[$n].Background='Transparent'}
 $active=@{home='Home';all='All';artists='Artists';history='History';fav='Fav';social='Social'}[$script:view];if($active){$ui[$active].Background='#32171D'}
 $isSystem=Test-SystemView $script:view
 $isEntityRoot=($script:view -eq 'artists')
 $isEntityDetail=$script:view.StartsWith('artist::')
 $ui.RemoveList.Visibility = if($isSystem){'Collapsed'}else{'Visible'}
 $ui.EditList.Visibility=$ui.RemoveList.Visibility
 $isHome=($script:view -eq 'home' -and [string]::IsNullOrWhiteSpace($query))
 $isSocial=($script:view -eq 'social')
 $ui.HomeDashboard.Visibility=if($isHome){'Visible'}else{'Collapsed'}
 $ui.SocialPanel.Visibility=if($isSocial){'Visible'}else{'Collapsed'}
 $ui.EntityBrowser.Visibility=if($isEntityRoot){'Visible'}else{'Collapsed'}
 $ui.LibraryPanel.Visibility=if($isHome -or $isEntityRoot -or $isSocial){'Collapsed'}else{'Visible'}
 $ui.ActionBar.Visibility=if($isHome -or $isEntityRoot -or $isSocial){'Collapsed'}else{'Visible'}
 $ui.ViewHint.Text=if($isSocial){'Atesh Studio kullananların canlı aktivitesi'}elseif($isHome){'Kütüphanen sana göre şekillenir'}elseif($isEntityRoot){'Detay sayfası için çift tıkla'}elseif(-not $isSystem){'Kişisel seçkin · Çalmak için çift tıkla'}else{'Çalmak için çift tıkla'}
 $isPlaylist=(-not $isSystem)
 $ui.ViewTypeBadge.Visibility=if($isPlaylist -or $isEntityDetail){'Visible'}else{'Collapsed'}
 $ui.ViewTypeText.Text=if($isPlaylist){'ÇALMA LİSTESİ'}elseif($script:view.StartsWith('artist::')){'SANATÇI'}else{''}
 $ui.EntityBack.Visibility=if($isEntityDetail){'Visible'}else{'Collapsed'}
 $ui.HistoryFilterBar.Visibility=if($script:view -eq 'history'){'Visible'}else{'Collapsed'}
 foreach($b in @('HistToday','HistYesterday','HistWeek','Hist30')){$ui[$b].Background='Transparent'}
 $hb=@{today='HistToday';yesterday='HistYesterday';week='HistWeek';'30'='Hist30'}[$script:historyRange];if($script:view -eq 'history' -and $hb){$ui[$hb].Background='#32171D'}
 if($script:view.StartsWith('artist::')){$tops=@($source|Sort-Object @{Expression={[int]$_.PlayCount};Descending=$true}|Select-Object -First 5|ForEach-Object {$_.Title});$ui.ViewHint.Text='En çok: '+($tops -join ' · ')}
 if($isHome){Refresh-HomeShelves}
 if($isEntityRoot){Refresh-EntityBrowser}
 $ui.Empty.Visibility = if((-not $isHome) -and (-not $isSocial) -and $rows.Count -eq 0){'Visible'}else{'Collapsed'}
 $ui.Empty.Text = if($library.Count -eq 0){"Müziklerini buraya sürükle bırak.`nVeya Müzik ekle ile dosyalarını seç."}elseif($script:view -eq 'history'){'Henüz dinleme geçmişi oluşmadı.'}elseif((-not (Test-SystemView $script:view)) -and -not $ui.Search.Text){"Listen hazır, şimdi şarkılarını seç.`nAşağıdaki Listeyi düzenle düğmesini kullan."}else{'Bu görünümde şarkı bulunamadı.'}
 foreach($row in $rows){if($row.Id -eq $selectedId){$ui.Tracks.SelectedItem=$row;break}}
 Update-Actions
 Refresh-CollectionVisual
}
function Get-SelectedTrack { if($ui.Tracks.SelectedItem){ return ($library | Where-Object Id -eq $ui.Tracks.SelectedItem.Id | Select-Object -First 1) }; return $null }
function Update-Actions {
 $track=Get-SelectedTrack
 foreach($key in @('PlaySelected','Favorite','TrackCover','Enqueue','AddList','RemoveList')){$ui[$key].IsEnabled=($null -ne $track)}
 $ui.Favorite.Content=if($track -and $track.Favorite){'♥   Favoriden çıkar'}else{'♡   Favoriye ekle'}
}
function Start-Track($track, [bool]$autoplay=$true, [double]$position=0) {
 if($null -eq $track){return}
 if(-not (Test-Path -LiteralPath $track.Path)){ $ui.Status.Text='Dosya bulunamadı. Taşınmış veya silinmiş olabilir.'; return }
 $script:current = $track
 if(-not $track.PSObject.Properties['PlayCount']){$track | Add-Member NoteProperty PlayCount 0}
 if(-not $track.PSObject.Properties['TotalSeconds']){$track | Add-Member NoteProperty TotalSeconds 0.0}
 if($autoplay){$track.PlayCount=[int]$track.PlayCount+1;$track.LastPlayed=[DateTime]::UtcNow.ToString('o');$wk=(Get-Date).ToString('yyyy-ww');if(-not $track.PSObject.Properties['WeekKey']){$track|Add-Member NoteProperty WeekKey $wk};if(-not $track.PSObject.Properties['WeekPlayCount']){$track|Add-Member NoteProperty WeekPlayCount 0};if($track.WeekKey -ne $wk){$track.WeekKey=$wk;$track.WeekPlayCount=0};$track.WeekPlayCount=[int]$track.WeekPlayCount+1;$script:history=@($track.Id)+@($script:history | Where-Object {$_ -ne $track.Id} | Select-Object -First 99);Save-Library}
 $script:lastListenTick=[DateTime]::UtcNow
 $player.Close()
 $script:pendingSeek=$position
 $player.Open([Uri]::new($track.Path))
 if($autoplay){$player.Play()}else{$player.Pause()}; $script:playing=$autoplay
 $ui.Play.Content=if($autoplay){'Ⅱ'}else{'▶'}; $ui.NowTitle.Text=$track.Title; $ui.NowArtist.Text=$track.Artist
 $ui.NowCover.Source=Get-Cover $track.Path
 $fallback=New-FallbackBrush ($track.Artist+'|'+$track.Title);$initial=Get-Initial $track;$ui.NowFallback.Background=$fallback;$ui.NowInitial.Text=$initial;$ui.SideNowFallback.Background=$fallback;$ui.SideNowInitial.Text=$initial
 $ui.SideNowCover.Source=$ui.NowCover.Source; $ui.SideNowTitle.Text=$track.Title; $ui.SideNowArtist.Text=$track.Artist; $ui.SideFavorite.Content=if($track.Favorite){'♥'}else{'♡'}; $ui.SideNowMeta.Text=($(if($track.Album){$track.Album + '  •  '}else{''})) + ([int]$track.PlayCount).ToString() + ' dinleme'
 $script:scene.SetCover($ui.NowCover.Source)
 $ui.Seek.Value=0;$ui.Duration.Text='0:00'
 Refresh-Queue
 $ui.Status.Text='Çalıyor: ' + $track.Title
 if($autoplay){Set-AteshSocialTrack $track.Title $track.Artist;Add-AteshListeningHistory $track.Title $track.Artist}
}
function Get-PlaybackQueueForView {
 # Çalma sırası, şarkının hangi görünümden başlatıldığına göre belirlenir.
 # "Tüm şarkılar" görünümünde arama/filtre ekranda açık olsa bile tüm kütüphane kullanılır.
 if($script:view -eq 'all'){
  return @($library | ForEach-Object {$_.Id})
 }
 # Diğer görünümlerde ekranda görünen sıra korunur (çalma listesi, favoriler, sanatçı, albüm, geçmiş vb.).
 return @($ui.Tracks.ItemsSource | ForEach-Object {$_.Id})
}
function Play-Selection {
 $track=Get-SelectedTrack
 if($track){
  $script:queue=@(Get-PlaybackQueueForView)
  # Seçilen şarkı görünümdeyse kuyrukta mutlaka yer almalı.
  if($script:queue -notcontains $track.Id){$script:queue=@($track.Id)+@($script:queue)}
  Save-Library
  Start-Track $track
 }
 else {$ui.Status.Text='Önce bir şarkı seç.'}
}
function Move-Track([int]$step) {
 if($script:queue.Count -eq 0){return}
 $index=[Array]::IndexOf($script:queue,$script:current.Id)
 if(-not $script:current){$index=if($step -lt 0){0}else{-1}}
 if($script:shuffle -and $script:queue.Count -gt 1){$id=($script:queue | Where-Object {$_ -ne $script:current.Id} | Get-Random)}
 else {$id=$script:queue[(($index+$step+$script:queue.Count)%$script:queue.Count)]}
 Start-Track ($library | Where-Object Id -eq $id | Select-Object -First 1)
}
function Format-Time([double]$seconds){$span=[TimeSpan]::FromSeconds([Math]::Max(0,$seconds));return ('{0}:{1:00}' -f [int][Math]::Floor($span.TotalMinutes),$span.Seconds)}
function Import-Music([string[]]$paths) {
 $added=0;$skipped=0
 foreach($path in $paths){
  if(-not (Test-Path -LiteralPath $path -PathType Leaf) -or [IO.Path]::GetExtension($path).ToLowerInvariant() -notin @('.mp3','.wav','.m4a','.aac','.wma')){$skipped++;continue}
  if(@($library | Where-Object Path -eq $path).Count -gt 0){$skipped++;continue}
  $info=Read-MusicInfo $path
  [void]$library.Add([pscustomobject]@{Id=[Guid]::NewGuid().ToString();Path=$path;Title=$info.Title;Artist=$info.Artist;Album=$info.Album;Favorite=$false;Lists=@();DateAdded=[DateTime]::UtcNow.ToString('o');PlayCount=0;TotalSeconds=0.0;LastPlayed='';WeekKey='';WeekPlayCount=0;DurationSeconds=0.0});$added++
 }
 Save-Library;Refresh-Tracks;$ui.Status.Text="$added şarkı eklendi, $skipped dosya atlandı (yinelenen veya desteklenmeyen)."
}
function Scan-MusicFolder([string]$folder) {
 if(-not (Test-Path -LiteralPath $folder -PathType Container)){return}
 $files=@(Get-ChildItem -LiteralPath $folder -File -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.Extension.ToLowerInvariant() -in @('.mp3','.wav','.m4a','.aac','.wma')})
 $repaired=0
 foreach($track in @($library | Where-Object {-not (Test-Path -LiteralPath $_.Path)})){
  $name=[IO.Path]::GetFileName($track.Path);$matches=@($files | Where-Object {$_.Name -ieq $name})
  if($matches.Count -eq 1){$track.Path=$matches[0].FullName;$repaired++}
 }
 $before=$library.Count;Import-Music ($files | ForEach-Object {$_.FullName});$added=$library.Count-$before
 $missing=@($library | Where-Object {-not (Test-Path -LiteralPath $_.Path)}).Count
 Save-Library;Refresh-Tracks
 $ui.Status.Text="Klasör tarandı: $added yeni şarkı, $repaired taşınmış dosya eşleştirildi, $missing kayıp dosya kaldı."
}
function Refresh-Queue {
 $selected=$ui.QueueTracks.SelectedIndex;$number=0
 $rows=@(foreach($id in $script:queue){$track=$library | Where-Object Id -eq $id | Select-Object -First 1;if($track){$number++;$initial=if($track.Artist){$track.Artist.Trim().Substring(0,1).ToUpperInvariant()}elseif($track.Title){$track.Title.Trim().Substring(0,1).ToUpperInvariant()}else{'A'};[pscustomobject]@{Id=$id;Artist=$track.Artist;Label=($(if($script:current -and $script:current.Id -eq $id){'▶  '}else{"$number.  "})+$track.Title);Cover=(Get-Cover $track.Path);Initial=$initial}}})
 $ui.QueueTracks.ItemsSource=$rows
 $ui.SideQueue.ItemsSource=@($rows | Select-Object -First 8); $ui.SideQueueCount.Text="·  $($rows.Count) PARÇA"
 if($rows.Count -gt 0){$ui.QueueTracks.SelectedIndex=[Math]::Min($selected,$rows.Count-1)}
 $ui.QueueCount.Text="$($rows.Count) şarkı"
 $ui.QueueEmpty.Visibility=if($rows.Count){'Collapsed'}else{'Visible'}
 Update-QueueActions
}
function Update-QueueActions {
 $i=$ui.QueueTracks.SelectedIndex
 $ui.QueueUp.IsEnabled=($i -gt 0);$ui.QueueDown.IsEnabled=($i -ge 0 -and $i -lt $script:queue.Count-1)
 $ui.QueueRemove.IsEnabled=($i -ge 0);$ui.QueuePlay.IsEnabled=($i -ge 0)
}
function Shift-Queue([int]$delta){
 $i=$ui.QueueTracks.SelectedIndex;$j=$i+$delta
 if($i -lt 0 -or $j -lt 0 -or $j -ge $script:queue.Count){return}
 $temp=$script:queue[$i];$script:queue[$i]=$script:queue[$j];$script:queue[$j]=$temp
 Refresh-Queue;$ui.QueueTracks.SelectedIndex=$j;Save-Library
}
if(Test-Path -LiteralPath $dataFile){
 try {
  $saved=Get-Content -LiteralPath $dataFile -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach($track in @($saved.Tracks)){if($track -and $track.Id -and $track.Path){
   if(-not $track.PSObject.Properties['Album']){$info=Read-MusicInfo $track.Path;$track.Title=$info.Title;$track.Artist=$info.Artist;$track | Add-Member NoteProperty Album $info.Album}
   if(-not $track.PSObject.Properties['DateAdded']){$track | Add-Member NoteProperty DateAdded ([DateTime]::UtcNow.ToString('o'))}
   if(-not $track.PSObject.Properties['PlayCount']){$track | Add-Member NoteProperty PlayCount 0}
   if(-not $track.PSObject.Properties['TotalSeconds']){$track | Add-Member NoteProperty TotalSeconds 0.0}
   if(-not $track.PSObject.Properties['LastPlayed']){$track | Add-Member NoteProperty LastPlayed ''}
   if(-not $track.PSObject.Properties['DurationSeconds']){$track | Add-Member NoteProperty DurationSeconds 0.0}
   [void]$library.Add($track)
  }}
  foreach($list in @($saved.Lists)){if($list){[void]$lists.Add([string]$list)}}
  if($saved.CollectionMeta){foreach($property in $saved.CollectionMeta.PSObject.Properties){if($lists -contains $property.Name){$script:collectionMeta[$property.Name]=@{Cover=[string]$property.Value.Cover;Order=@($property.Value.Order)}}}}
  $script:history=@($saved.History | Where-Object {$_ -in @($library | ForEach-Object {$_.Id})} | Select-Object -Unique)
  $script:queue=@($saved.Queue | Where-Object {$_ -in @($library | ForEach-Object {$_.Id})} | Select-Object -Unique)
 }catch{$ui.Status.Text='Kayıtlı kütüphane okunamadı. Mevcut dosya kutuphane-bozuk.json olarak korundu.'; Copy-Item -LiteralPath $dataFile -Destination (Join-Path $script:dataDir 'kutuphane-bozuk.json') -Force}
}
$ui.Lists.ItemsSource=$lists.ToArray()
if(Test-Path -LiteralPath $dataFile){Save-Library}
$ui.ScanFolder.Add_Click({$dialog=[System.Windows.Forms.FolderBrowserDialog]::new();$dialog.Description='Müzik klasörünü seç';if($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){Scan-MusicFolder $dialog.SelectedPath}})
$ui.Import.Add_Click({
 $dialog=[Microsoft.Win32.OpenFileDialog]::new();$dialog.Multiselect=$true
 $dialog.Filter='Müzik dosyaları|*.mp3;*.wav;*.m4a;*.aac;*.wma|Tüm dosyalar|*.*'
 if($dialog.ShowDialog($window)){
  Import-Music $dialog.FileNames
 }
})
$ui.Home.Add_Click({$script:view='home';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Ana Sayfa';Refresh-Tracks})
$ui.QuickAll.Add_Click({$script:view='all';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Tüm şarkılar';Refresh-Tracks})
$ui.QuickHistory.Add_Click({$script:view='history';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Son çalınanlar';Refresh-Tracks})
$ui.QuickFav.Add_Click({$script:view='fav';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Favoriler';Refresh-Tracks})
$ui.Artists.Add_Click({$script:view='artists';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Sanatçılar';Refresh-Tracks})
$ui.EntityList.Add_MouseDoubleClick({if($ui.EntityList.SelectedItem){$item=$ui.EntityList.SelectedItem;$script:view='artist::'+$item.Name;$ui.Heading.Text=$item.Name;Refresh-Tracks}})
$ui.EntityBack.Add_Click({if($script:view.StartsWith('artist::')){$script:view='artists';$ui.Heading.Text='Sanatçılar'};Refresh-Tracks})
$ui.History.Add_Click({$script:view='history';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Son çalınanlar';Refresh-Tracks})
$ui.SeeHistory.Add_Click({$script:view='history';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Son çalınanlar';Refresh-Tracks})
$ui.SmartWeek.Add_Click({$script:view='smartweek';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Bu hafta en çok dinlediklerin';Refresh-Tracks})
$ui.SmartForgotten.Add_Click({$script:view='smartforgotten';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Uzun zamandır dinlemediklerin';Refresh-Tracks})
$ui.SmartNewest.Add_Click({$script:view='smartnewest';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Son eklenenler';Refresh-Tracks})
$ui.SmartFavMix.Add_Click({$script:view='smartfavmix';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Favorilerden karışık';Refresh-Tracks})
$ui.HistToday.Add_Click({$script:historyRange='today';Refresh-Tracks})
$ui.HistYesterday.Add_Click({$script:historyRange='yesterday';Refresh-Tracks})
$ui.HistWeek.Add_Click({$script:historyRange='week';Refresh-Tracks})
$ui.Hist30.Add_Click({$script:historyRange='30';Refresh-Tracks})
$ui.SideFavorite.Add_Click({if($script:current){$script:current.Favorite=-not [bool]$script:current.Favorite;Save-Library;Refresh-Tracks;$ui.SideFavorite.Content=if($script:current.Favorite){'♥'}else{'♡'}}})
$ui.SideAddList.Add_Click({
 if(-not $script:current){return}
 if($lists.Count -eq 0){Open-CollectionEditor;return}
 $menu=[Windows.Controls.ContextMenu]::new()
 foreach($name in $lists){
  $item=[Windows.Controls.MenuItem]::new();$item.Header=$name;$item.Tag=@{Track=$script:current;Name=$name}
  $item.Add_Click({param($sender,$eventArgs) $t=$sender.Tag.Track;$n=$sender.Tag.Name;if(@($t.Lists) -notcontains $n){$t.Lists=@($t.Lists)+@($n);Save-Library;Refresh-Tracks};$ui.Status.Text='Listeye eklendi: '+$n})
  [void]$menu.Items.Add($item)
 }
 $menu.PlacementTarget=$ui.SideAddList;$menu.IsOpen=$true
})
$ui.SideQueueOpen.Add_Click({$ui.QueuePanel.Visibility='Visible'})
function Refresh-SettingsUI {$ui.AutoScan.IsChecked=[bool]$script:appSettings.AutoScan;$ui.WatchFolders.ItemsSource=@($script:appSettings.WatchFolders)}
function Scan-WatchedFolders {foreach($folder in @($script:appSettings.WatchFolders)){if(Test-Path -LiteralPath $folder){Scan-MusicFolder $folder}}}
function New-AteshBackup {
 $dlg=[Microsoft.Win32.SaveFileDialog]::new();$dlg.Filter='Atesh Studio yedeği (*.zip)|*.zip';$dlg.FileName='AteshStudio-Yedek-'+(Get-Date -Format 'yyyyMMdd-HHmm')+'.zip'
 if($dlg.ShowDialog()){$temp=Join-Path $env:TEMP ('AteshBackup-'+[guid]::NewGuid());New-Item -ItemType Directory -Path $temp|Out-Null;foreach($f in @('kutuphane.json','oynatma.json','ayarlar.json')){if(Test-Path (Join-Path $script:dataDir $f)){Copy-Item (Join-Path $script:dataDir $f) $temp}};if(Test-Path (Join-Path $script:dataDir 'kapaklar')){Copy-Item (Join-Path $script:dataDir 'kapaklar') $temp -Recurse};Compress-Archive -Path (Join-Path $temp '*') -DestinationPath $dlg.FileName -Force;Remove-Item $temp -Recurse -Force;[Windows.MessageBox]::Show('Yedek oluşturuldu.','Atesh studio')|Out-Null}
}
function Restore-AteshBackup {
 $dlg=[Microsoft.Win32.OpenFileDialog]::new();$dlg.Filter='Atesh Studio yedeği (*.zip)|*.zip'
 if($dlg.ShowDialog()){$temp=Join-Path $env:TEMP ('AteshRestore-'+[guid]::NewGuid());Expand-Archive -LiteralPath $dlg.FileName -DestinationPath $temp -Force;foreach($f in @('kutuphane.json','oynatma.json','ayarlar.json')){if(Test-Path (Join-Path $temp $f)){Copy-Item (Join-Path $temp $f) (Join-Path $script:dataDir $f) -Force}};if(Test-Path (Join-Path $temp 'kapaklar')){Copy-Item (Join-Path $temp 'kapaklar') (Join-Path $script:dataDir 'kapaklar') -Recurse -Force};Remove-Item $temp -Recurse -Force;[Windows.MessageBox]::Show('Yedek geri yüklendi. Değişikliklerin tamamı için Atesh Studio yeniden başlatılacak.','Atesh studio')|Out-Null;$window.Close()}
}
$ui.Settings.Add_Click({Refresh-SettingsUI;$ui.SettingsOverlay.Visibility='Visible'})
$ui.SettingsClose.Add_Click({$ui.SettingsOverlay.Visibility='Collapsed'})
$ui.CheckUpdate.Add_Click({
 try{
  $updater=Join-Path $script:homeDir 'Atesh-Updater.exe'
  if(Test-Path -LiteralPath $updater){Start-Process -FilePath $updater -ArgumentList '--check','--app-pid',([Diagnostics.Process]::GetCurrentProcess().Id) | Out-Null}
  else{[Windows.MessageBox]::Show('Güncelleme bileşeni bulunamadı. Kurulumu onar.','Atesh studio')|Out-Null}
 }catch{[Windows.MessageBox]::Show('Güncelleme denetimi başlatılamadı.','Atesh studio')|Out-Null}
})
$ui.AutoScan.Add_Click({$script:appSettings.AutoScan=[bool]$ui.AutoScan.IsChecked;Save-AppSettings})
$ui.WatchAdd.Add_Click({$d=[System.Windows.Forms.FolderBrowserDialog]::new();$d.Description='İzlenecek müzik klasörünü seç';if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){if(@($script:appSettings.WatchFolders) -notcontains $d.SelectedPath){$script:appSettings.WatchFolders=@($script:appSettings.WatchFolders)+@($d.SelectedPath);Save-AppSettings;Refresh-SettingsUI}}})
$ui.WatchRemove.Add_Click({if($ui.WatchFolders.SelectedItem){$sel=[string]$ui.WatchFolders.SelectedItem;$script:appSettings.WatchFolders=@($script:appSettings.WatchFolders|Where-Object {$_ -ne $sel});Save-AppSettings;Refresh-SettingsUI}})
$ui.WatchScanNow.Add_Click({Scan-WatchedFolders;Refresh-SettingsUI})
$ui.BackupLibrary.Add_Click({New-AteshBackup})
$ui.RestoreLibrary.Add_Click({Restore-AteshBackup})
foreach($shelf in @($ui.RecentShelf,$ui.ForYouShelf,$ui.TopShelf,$ui.NewestShelf)){$shelf.Add_MouseDoubleClick({param($sender,$e) $track=Get-ShelfTrack $sender;if($track){$script:queue=@($sender.ItemsSource | ForEach-Object {$_.Id});Save-Library;Start-Track $track}})}
$ui.All.Add_Click({$script:view='all';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Tüm şarkılar';Refresh-Tracks})
$ui.Social.Add_Click({$script:view='social';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Topluluk';$ui.Search.Text='';Refresh-Tracks;try{$ui.MainViewHeader.Visibility='Collapsed'}catch{};Show-SocialSubview 'live';Refresh-SocialUI})
$ui.SocialRefresh.Add_Click({Refresh-SocialUI})
$ui.SocialSave.Add_Click({$privacy=if($ui.SocialPrivacy.SelectedIndex -eq 1){'hidden'}else{'public'};Set-AteshSocialProfile $ui.SocialUsername.Text $privacy;Refresh-SocialUI})
$ui.SocialLiveTab.Add_Click({Show-SocialSubview 'live';Refresh-SocialUI})
$ui.SocialProfileTab.Add_Click({Show-SocialSubview 'profile'})
$ui.SocialFollowingTab.Add_Click({Show-SocialSubview 'following'})
$ui.ProfileAvatarChoose.Add_Click({try{$dlg=[Microsoft.Win32.OpenFileDialog]::new();$dlg.Filter='Profil resmi (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp';if($dlg.ShowDialog()){ $ext=[IO.Path]::GetExtension($dlg.FileName).ToLowerInvariant();foreach($old in @(Get-ChildItem -LiteralPath $script:dataDir -Filter 'profil-avatar.*' -ErrorAction SilentlyContinue)){try{Remove-Item -LiteralPath $old.FullName -Force}catch{}};$dest=Join-Path $script:dataDir ('profil-avatar'+$ext);Copy-Item -LiteralPath $dlg.FileName -Destination $dest -Force;$script:socialState.LocalAvatarPath=$dest;Save-AteshSocialState;Set-ProfilePreviewAvatarSource;$ui.ProfileLocalAvatarHint.Text='Yerel fotoğraf aktif · Profilim ve kendi Canlı kartında kullanılıyor.'}}catch{$ui.ProfileLocalAvatarHint.Text='Fotoğraf seçilemedi.'}})
$ui.ProfileAvatarClear.Add_Click({try{$path=[string]$script:socialState.LocalAvatarPath;if($path -and (Test-Path -LiteralPath $path)){Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue};$script:socialState.LocalAvatarPath='';Save-AteshSocialState;Set-ProfilePreviewAvatarSource;$ui.ProfileLocalAvatarHint.Text='Yerel profil fotoğrafı temizlendi.'}catch{}})
$ui.ProfileSave.Add_Click({$privacy=if($ui.ProfilePrivacy.SelectedIndex -eq 1){'hidden'}else{'public'};if(Save-AteshSocialProfileV54 $ui.ProfileUsername.Text $privacy $ui.ProfileBio.Text $ui.ProfileAvatarUrl.Text){$ui.SocialCount.Text='Profil kaydedildi.';$ui.SocialUsername.Text=$script:socialState.Username;$ui.SocialPrivacy.SelectedIndex=if($script:socialState.Privacy -eq 'hidden'){1}else{0};Refresh-SocialProfileUI;Refresh-SocialUI}else{$ui.SocialCount.Text='Profil kaydedilemedi.'}})
$ui.FollowAdd.Add_Click({$target=Find-AteshSocialUser $ui.FollowUsername.Text;if(-not $target){$ui.FollowStatus.Text='Kullanıcı bulunamadı.'}elseif([string]$target.user_id -eq $script:socialState.UserId){$ui.FollowStatus.Text='Kendini takip edemezsin.'}elseif(Follow-AteshSocialUser ([string]$target.user_id)){$ui.FollowStatus.Text=([string]$target.username)+' takip edildi.';Refresh-SocialFollowingUI}else{$ui.FollowStatus.Text='Takip işlemi başarısız.'}})
$ui.FollowingUsers.AddHandler([System.Windows.Controls.Button]::ClickEvent,[System.Windows.RoutedEventHandler]{param($sender,$e) if($e.OriginalSource -is [System.Windows.Controls.Button] -and $e.OriginalSource.Tag){if(Unfollow-AteshSocialUser ([string]$e.OriginalSource.Tag)){$ui.FollowStatus.Text='Takip bırakıldı.';Refresh-SocialFollowingUI};$e.Handled=$true}})
$ui.Fav.Add_Click({$script:view='fav';$ui.Lists.SelectedIndex=-1;$ui.Heading.Text='Favoriler';Refresh-Tracks})
$ui.Search.Add_TextChanged({Refresh-Tracks})
$ui.NewList.Add_Click({Open-CollectionEditor})
$ui.EditList.Add_Click({Open-CollectionEditor $script:view})
$ui.CollectionClose.Add_Click({$ui.CollectionOverlay.Visibility='Collapsed'})
$ui.CollectionCancel.Add_Click({$ui.CollectionOverlay.Visibility='Collapsed'})
$ui.CollectionSave.Add_Click({Save-CollectionEditor})
$ui.SelectAllTracks.Add_Click({if($ui.CollectionTracks.SelectedItems.Count -eq $ui.CollectionTracks.Items.Count){$ui.CollectionTracks.UnselectAll()}else{$ui.CollectionTracks.SelectAll()}})
$ui.CollectionTracks.Add_SelectionChanged({$ui.CollectionCount.Text="$($ui.CollectionTracks.SelectedItems.Count) şarkı seçildi"})
$ui.CollectionName.Add_TextChanged({$ui.CollectionError.Text=''})
$ui.CollectionName.Add_KeyDown({param($sender,$e) if($e.Key -eq 'Return'){Save-CollectionEditor;$e.Handled=$true}})
$window.Add_PreviewKeyDown({param($sender,$e) if($e.Key -eq 'Escape' -and $ui.CollectionOverlay.Visibility -eq 'Visible'){$ui.CollectionOverlay.Visibility='Collapsed';$e.Handled=$true}})
$ui.Lists.Add_SelectionChanged({if($ui.Lists.SelectedItem){$script:view=[string]$ui.Lists.SelectedItem;$ui.Heading.Text=$script:view;Refresh-Tracks}})
$ui.Favorite.Add_Click({$track=Get-SelectedTrack;if($track){$track.Favorite=-not $track.Favorite;Save-Library;Refresh-Tracks}else{$ui.Status.Text='Önce bir şarkı seç.'}})
$ui.AddList.Add_Click({
 $track=Get-SelectedTrack
 if(-not $track){$ui.Status.Text='Önce bir şarkı seç.';return}
 if($lists.Count -eq 0){Open-CollectionEditor;return}
 $menu=[Windows.Controls.ContextMenu]::new()
 foreach($name in $lists){
  $item=[Windows.Controls.MenuItem]::new();$item.Header=$name;$item.Tag=@{Track=$track;Name=$name}
  $item.Add_Click({param($sender,$eventArgs) $t=$sender.Tag.Track;$n=$sender.Tag.Name;if(@($t.Lists) -notcontains $n){$t.Lists=@($t.Lists)+@($n);Save-Library;Refresh-Tracks};$ui.Status.Text='Listeye eklendi: '+$n})
  [void]$menu.Items.Add($item)
 }
 $menu.PlacementTarget=$ui.AddList;$menu.IsOpen=$true
})
$ui.RemoveList.Add_Click({$track=Get-SelectedTrack;if($track -and $script:view -notin @('all','fav')){$track.Lists=@($track.Lists | Where-Object {$_ -ne $script:view});Save-Library;Refresh-Tracks;$ui.Status.Text='Şarkı listeden çıkarıldı.'}else{$ui.Status.Text='Bir çalma listesini açıp şarkı seç.'}})
$ui.PlaySelected.Add_Click({Play-Selection})
$ui.QueueToggle.Add_Click({$ui.QueuePanel.Visibility=if($ui.QueuePanel.Visibility -eq 'Visible'){'Collapsed'}else{'Visible'};Refresh-Queue})
$ui.QueueClose.Add_Click({$ui.QueuePanel.Visibility='Collapsed'})
$ui.Enqueue.Add_Click({
 $track=Get-SelectedTrack
 if($track){if($script:queue -notcontains $track.Id){$script:queue=@($script:queue)+@($track.Id);Save-Library};Refresh-Queue;$ui.Status.Text='Kuyrukta: '+$track.Title}
})
$ui.QueueTracks.Add_SelectionChanged({Update-QueueActions})
$ui.QueuePlay.Add_Click({if($ui.QueueTracks.SelectedItem){Start-Track ($library | Where-Object Id -eq $ui.QueueTracks.SelectedItem.Id | Select-Object -First 1)}})
$ui.QueueTracks.Add_MouseDoubleClick({if($ui.QueueTracks.SelectedItem){Start-Track ($library | Where-Object Id -eq $ui.QueueTracks.SelectedItem.Id | Select-Object -First 1)}})
$ui.QueueUp.Add_Click({Shift-Queue -1})
$ui.QueueDown.Add_Click({Shift-Queue 1})
$ui.QueueRemove.Add_Click({$i=$ui.QueueTracks.SelectedIndex;if($i -ge 0){$script:queue=@(for($n=0;$n -lt $script:queue.Count;$n++){if($n -ne $i){$script:queue[$n]}});Refresh-Queue;Save-Library}})
$window.Add_PreviewDragOver({param($sender,$e)
 $e.Effects=if($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)){[Windows.DragDropEffects]::Copy}else{[Windows.DragDropEffects]::None};$e.Handled=$true
})
$window.Add_PreviewDrop({param($sender,$e)
 if($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)){Import-Music ([string[]]$e.Data.GetData([Windows.DataFormats]::FileDrop))};$e.Handled=$true
})
$ui.Tracks.Add_SelectionChanged({Update-Actions})
$ui.Tracks.Add_MouseDoubleClick({Play-Selection})
$ui.Play.Add_Click({Invoke-MediaCommand 'toggle'})
$ui.Prev.Add_Click({Invoke-MediaCommand 'previous'})
$ui.Next.Add_Click({Invoke-MediaCommand 'next'})
$ui.Shuffle.Add_Click({$script:shuffle=-not $script:shuffle;$ui.Shuffle.Background=if($script:shuffle){'#702333'}else{'Transparent'};$ui.Shuffle.ToolTip=if($script:shuffle){'Karışık çalma açık'}else{'Karışık çalma kapalı'}})
$ui.Repeat.Add_Click({$script:repeat=-not $script:repeat;$ui.Repeat.Background=if($script:repeat){'#702333'}else{'Transparent'};$ui.Repeat.ToolTip=if($script:repeat){'Şarkı tekrarı açık'}else{'Şarkı tekrarı kapalı'}})
$ui.Volume.Add_ValueChanged({$player.Volume=$ui.Volume.Value})
$ui.Seek.Add_PreviewMouseLeftButtonUp({if($player.NaturalDuration.HasTimeSpan){$player.Position=[TimeSpan]::FromSeconds($ui.Seek.Value)}})
$ui.Seek.Add_PreviewKeyUp({if($player.NaturalDuration.HasTimeSpan){$player.Position=[TimeSpan]::FromSeconds($ui.Seek.Value)}})
$player.Add_MediaOpened({
 if($player.NaturalDuration.HasTimeSpan){
  $ui.Seek.Maximum=$player.NaturalDuration.TimeSpan.TotalSeconds;$ui.Duration.Text=Format-Time $ui.Seek.Maximum
  if($script:current){if(-not $script:current.PSObject.Properties['DurationSeconds']){$script:current|Add-Member NoteProperty DurationSeconds 0.0};$script:current.DurationSeconds=[double]$ui.Seek.Maximum;Save-Library}
  if($null -ne $script:pendingSeek){$player.Position=[TimeSpan]::FromSeconds([Math]::Min([Math]::Max(0.0,[double]$script:pendingSeek),[Math]::Max(0.0,$ui.Seek.Maximum-0.1)));$script:pendingSeek=$null}
  $ui.Seek.Value=$player.Position.TotalSeconds;$ui.Elapsed.Text=Format-Time $player.Position.TotalSeconds
 }
 Sync-Mini
})
$player.Add_MediaEnded({
 if($script:repeat){$player.Position=[TimeSpan]::Zero;$player.Play()}
 elseif($script:queue.Count -gt 0 -and ($script:shuffle -or [Array]::IndexOf($script:queue,$script:current.Id) -lt $script:queue.Count-1)){Move-Track 1}
 else{$player.Stop();$script:playing=$false;$ui.Play.Content='▶';$ui.Status.Text='Çalma kuyruğu tamamlandı.'}
})
$player.Add_MediaFailed({$script:pendingSeek=$null;$script:playing=$false;$ui.Play.Content='▶';$ui.Status.Text='Bu dosya çalınamadı. Dosyayı ve ses biçimini kontrol et.';Sync-Mini})
. (Join-Path $homeDir 'PlaybackExtras.ps1')
$timer=[Windows.Threading.DispatcherTimer]::new();$timer.Interval=[TimeSpan]::FromMilliseconds(400)
$motionTimer=[Windows.Threading.DispatcherTimer]::new();$motionTimer.Interval=[TimeSpan]::FromMilliseconds(33)
$socialTimer=[Windows.Threading.DispatcherTimer]::new();$socialTimer.Interval=[TimeSpan]::FromSeconds(30);$socialTimer.Add_Tick({if($script:current -and $script:playing){[void](Send-AteshSocialStatus $true ([string]$script:current.Title) ([string]$script:current.Artist))}else{[void](Send-AteshSocialStatus $true '' '')}})
$motionTimer.Add_Tick({if($script:motionEnabled -and $script:playing -and $window.WindowState -ne 'Minimized'){$script:scene.Spin.Angle=($script:scene.Spin.Angle+0.75)%360}else{$motionTimer.Stop()}})
$timer.Add_Tick({if($script:current){if(-not $ui.Seek.IsMouseCaptureWithin){$ui.Seek.Value=$player.Position.TotalSeconds};$ui.Elapsed.Text=Format-Time $player.Position.TotalSeconds;if($script:playing){$now=[DateTime]::UtcNow;$delta=($now-$script:lastListenTick).TotalSeconds;if($delta -gt 0 -and $delta -lt 5){$script:current.TotalSeconds=[double]$script:current.TotalSeconds+$delta};$script:lastListenTick=$now}}})
$timer.Add_Tick({if($mini.IsVisible){Sync-Mini};if(([DateTime]::UtcNow-$script:lastPlaybackSave).TotalSeconds -ge 5){Save-Playback}})
$timer.Add_Tick({if($script:motionEnabled -and $script:playing -and $window.WindowState -ne 'Minimized' -and -not $motionTimer.IsEnabled){$motionTimer.Start()}})
$window.Add_Closed({$timer.Stop();$motionTimer.Stop();$socialTimer.Stop();Stop-AteshSocial;$player.Close();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:shellMetadata)})
Initialize-CollectionExtras
if(-not $LoadOnly -and -not $SelfTest){Initialize-AteshSocial;$socialTimer.Start()}
$script:view='home';$ui.Heading.Text='Ana Sayfa'
if($script:appSettings.AutoScan -and @($script:appSettings.WatchFolders).Count -gt 0){Scan-WatchedFolders}
Refresh-Tracks
Refresh-Queue
if($LoadOnly){return}
if($SelfTest){
 if($ui.Count.Text -ne '0 şarkı' -and $library.Count -eq 0){throw 'Empty library rendering failed'}
 if((Format-Time 125) -ne '2:05'){throw 'Time formatting failed'}
 $testTrack=[pscustomobject]@{Id='test';Path='C:\test.mp3';Title='Deneme Şarkısı';Artist='Sanatçı';Album='Test';Favorite=$true;Lists=@('Test listesi');DateAdded=[DateTime]::UtcNow.ToString('o');PlayCount=1;TotalSeconds=10.0;LastPlayed=[DateTime]::UtcNow.ToString('o')}
 [void]$library.Add($testTrack);$script:view='fav';Refresh-Tracks
 if(@($ui.Tracks.ItemsSource | Where-Object Id -eq 'test').Count -ne 1){throw 'Favorite filtering failed'}
 $script:view='Test listesi';Refresh-Tracks
 if(@($ui.Tracks.ItemsSource | Where-Object Id -eq 'test').Count -ne 1){throw 'Playlist filtering failed'}
 $ui.Search.Text='no-match-123';Refresh-Tracks
 if($ui.Tracks.ItemsSource.Count -ne 0){throw 'Search filtering failed'}
 $surface=$window.Content
 $surface.Measure([Windows.Size]::new(1280,860));$surface.Arrange([Windows.Rect]::new(0,0,1280,860));$surface.UpdateLayout()
 $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new(1280,860,96,96,[Windows.Media.PixelFormats]::Pbgra32)
 $library.Remove($testTrack);$script:view='all';$ui.Search.Clear();Refresh-Tracks;$surface.UpdateLayout();$bitmap.Render($surface)
 $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new();$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
 $stream=[IO.File]::Create((Join-Path $homeDir 'onizleme.png'));$encoder.Save($stream);$stream.Close()
 'PASS: XAML, controls, favorites, playlist filtering, search, time formatting, window rendering'
 $player.Close();exit
}
Restore-Playback
if($WaitForLauncher){
 $ready=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::ManualReset,'Local\AteshStudioReady')
 $show=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::AutoReset,'Local\AteshStudioShow')
 try{$ready.Set() | Out-Null;[void]$show.WaitOne(8000)}finally{$ready.Dispose();$show.Dispose()}
}
$timer.Start()
[void]$window.ShowDialog()
